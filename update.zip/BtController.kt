package com.nearchat.app.core

import android.annotation.SuppressLint
import android.app.Application
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.OpenableColumns
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlin.concurrent.thread
import kotlin.random.Random

/**
 * All Bluetooth logic: discovery, listening, connecting, encrypted messaging, file transfer,
 * profile exchange, read receipts, reactions, and saving/deleting chats on the phone.
 * UI only observes the StateFlows and calls the public functions.
 */
@SuppressLint("MissingPermission")
class BtController(private val app: Application) {

    companion object {
        val APP_UUID: UUID = UUID.fromString("7c1b5e2e-3f7a-4d52-9a6b-4e6e0c1f9a11")
        const val CHUNK = 16 * 1024
    }

    private val prefs = app.getSharedPreferences("nearchat", Context.MODE_PRIVATE)
    private val adapter: BluetoothAdapter? = app.getSystemService(BluetoothManager::class.java)?.adapter
    private val store = ChatStore(app)
    private val thumbDir = File(app.filesDir, "thumbs")
    private val voiceDir = File(app.filesDir, "voices")
    private val peerDir = File(app.filesDir, "peers")

    private val _s = MutableStateFlow(UiState(chats = store.list()))
    val state: StateFlow<UiState> = _s.asStateFlow()

    val themeMode = MutableStateFlow(prefs.getInt("theme", 0)) // 0 system, 1 light, 2 dark
    val readReceipts = MutableStateFlow(prefs.getBoolean("rr", true))
    val saveHistory = MutableStateFlow(prefs.getBoolean("hist", true))
    val fontLevel = MutableStateFlow(prefs.getInt("font", 1)) // 0 small, 1 medium, 2 large
    val wall = MutableStateFlow(prefs.getInt("wall", 0))
    val wallPath = MutableStateFlow<String?>(prefs.getString("wallpath", null)?.takeIf { File(it).exists() })
    val profile = MutableStateFlow(loadProfile())
    val appVisible = MutableStateFlow(true)
    val pins = MutableStateFlow<Set<String>>(prefs.getStringSet("pins", emptySet<String>())?.toSet() ?: emptySet())
    val favs = MutableStateFlow<Set<String>>(prefs.getStringSet("favs", emptySet<String>())?.toSet() ?: emptySet())
    val hiddenChats = MutableStateFlow<Set<String>>(prefs.getStringSet("hidden", emptySet<String>())?.toSet() ?: emptySet())

    @Volatile private var conn: Conn? = null
    @Volatile private var pendingConn: Conn? = null
    @Volatile private var server: BluetoothServerSocket? = null
    @Volatile private var connectingSock: BluetoothSocket? = null
    @Volatile private var attempt = 0

    private val sendPool = Executors.newSingleThreadExecutor()
    private val ioPool = Executors.newSingleThreadExecutor()
    private val outgoing = ConcurrentHashMap<Long, Uri>()
    private val cancelled = ConcurrentHashMap.newKeySet<Long>()
    private val offers = ConcurrentHashMap<Long, Pair<String, Long>>()
    private val receiving = ConcurrentHashMap<Long, FileOutputStream>()
    private val paths = ConcurrentHashMap<Long, File>()
    private val counts = ConcurrentHashMap<Long, Long>()
    private val lastPct = ConcurrentHashMap<Long, Int>()

    // ---------------------------------------------------------------- basics

    private fun loadProfile() = Profile(
        prefs.getString("pname", "") ?: "",
        prefs.getString("pbio", "") ?: "",
        prefs.getString("pphoto", null)?.takeIf { File(it).exists() },
    )

    fun bluetoothOn() = adapter?.isEnabled == true
    fun phoneName(): String = runCatching { adapter?.name }.getOrNull() ?: Build.MODEL

    /** Name shown to the other phone: profile name, or the phone's own name when none is set. */
    fun deviceName(): String = profile.value.name.trim().ifBlank { phoneName() }

    fun receivedDir(): File =
        File(app.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: app.filesDir, "NearChat").apply { mkdirs() }

    fun report(msg: String) = _s.update { it.copy(error = msg) }
    fun clearError() = _s.update { it.copy(error = null) }

    fun setTheme(mode: Int) {
        prefs.edit().putInt("theme", mode).apply()
        themeMode.value = mode
    }

    fun setReadReceipts(on: Boolean) {
        prefs.edit().putBoolean("rr", on).apply()
        readReceipts.value = on
    }

    fun setSaveHistory(on: Boolean) {
        prefs.edit().putBoolean("hist", on).apply()
        saveHistory.value = on
    }

    fun setFont(level: Int) {
        prefs.edit().putInt("font", level).apply()
        fontLevel.value = level
    }

    fun setWall(i: Int) {
        prefs.edit().putInt("wall", i).apply()
        wall.value = i
    }

    /** Uses a photo from the gallery as chat wallpaper (wall index 6). */
    fun setCustomWall(uri: Uri) {
        ioPool.execute {
            val bmp = Media.decodeStream({ app.contentResolver.openInputStream(uri) }, 1280)
            if (bmp == null) { report("Couldn't load the photo."); return@execute }
            val f = File(app.filesDir, "wall_${System.currentTimeMillis()}.jpg")
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 82, it) }
            wallPath.value?.let { runCatching { File(it).delete() } }
            prefs.edit().putString("wallpath", f.absolutePath).putInt("wall", 6).apply()
            wallPath.value = f.absolutePath
            wall.value = 6
        }
    }

    private fun toggleIn(flow: MutableStateFlow<Set<String>>, key: String, addr: String) {
        val n: Set<String> = if (addr in flow.value) flow.value - addr else flow.value + addr
        flow.value = n
        prefs.edit().putStringSet(key, n.toSet()).apply()
    }

    fun togglePin(addr: String) = toggleIn(pins, "pins", addr)
    fun toggleFav(addr: String) = toggleIn(favs, "favs", addr)
    fun toggleHide(addr: String) = toggleIn(hiddenChats, "hidden", addr)

    private fun upd(id: Long, save: Boolean = true, f: (Msg) -> Msg) {
        _s.update { s -> s.copy(messages = s.messages.map { if (it.id == id) f(it) else it }) }
        if (save) persist()
    }

    private fun addMsg(m: Msg) {
        _s.update { it.copy(messages = it.messages.filter { x -> x.id != m.id } + m) }
        persist()
    }

    private fun pack(id: Long, extra: ByteArray = ByteArray(0)): ByteArray =
        ByteBuffer.allocate(8 + extra.size).putLong(id).put(extra).array()

    private fun idOf(b: ByteArray): Long = ByteBuffer.wrap(b).long

    // ---------------------------------------------------------------- my profile

    fun saveProfile(name: String, bio: String) {
        val n = name.trim().take(25)
        val b = bio.trim().take(80)
        prefs.edit().putString("pname", n).putString("pbio", b).apply()
        profile.update { it.copy(name = n, bio = b) }
        pushProfile()
    }

    /** Sets (or removes, when uri is null) the profile photo. */
    fun setProfilePhoto(uri: Uri?) {
        ioPool.execute {
            var path: String? = null
            if (uri != null) {
                val bmp = Media.squareBitmap({ app.contentResolver.openInputStream(uri) }, 384)
                if (bmp == null) { report("Couldn't load the photo."); return@execute }
                val f = File(app.filesDir, "profile_${System.currentTimeMillis()}.jpg")
                FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                path = f.absolutePath
            }
            val old = profile.value.photo
            prefs.edit().putString("pphoto", path).apply()
            old?.let { runCatching { File(it).delete() } }
            profile.update { it.copy(photo = path) }
            pushProfile()
        }
    }

    /** Saves an already cropped square photo as the profile picture. */
    fun setProfilePhotoBitmap(bmp: Bitmap) {
        ioPool.execute {
            val f = File(app.filesDir, "profile_${System.currentTimeMillis()}.jpg")
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            val old = profile.value.photo
            prefs.edit().putString("pphoto", f.absolutePath).apply()
            old?.let { runCatching { File(it).delete() } }
            profile.update { it.copy(photo = f.absolutePath) }
            pushProfile()
        }
    }

    private fun pushProfile() {
        val c = conn ?: return
        thread { runCatching { sendProfile(c) } }
    }

    private fun sendProfile(c: Conn) {
        val p = profile.value
        val photo: ByteArray = p.photo?.let { path ->
            Media.decodeFile(path, 160)?.let { b ->
                val o = ByteArrayOutputStream()
                b.compress(Bitmap.CompressFormat.JPEG, 70, o)
                o.toByteArray()
            }
        } ?: ByteArray(0)
        val bo = ByteArrayOutputStream()
        val d = DataOutputStream(bo)
        d.writeUTF(p.name.trim().take(25))
        d.writeUTF(p.bio.trim().take(80))
        d.writeInt(photo.size)
        d.write(photo)
        d.flush()
        c.send(T.PROFILE, bo.toByteArray())
    }

    private fun onPeerProfile(c: Conn, name: String, bio: String, bytes: ByteArray) {
        val addr = _s.value.openAddr
        if (addr.isBlank() || conn !== c) return
        var photo: String? = _s.value.openInfo.photo
        if (bytes.isNotEmpty() && BitmapFactory.decodeByteArray(bytes, 0, bytes.size) != null) {
            peerDir.mkdirs()
            val prefix = addr.replace(Regex("[^A-Za-z0-9]"), "_")
            val f = File(peerDir, "${prefix}_${System.currentTimeMillis()}.jpg")
            f.writeBytes(bytes)
            peerDir.listFiles()?.filter { it.name.startsWith(prefix) && it != f }?.forEach { it.delete() }
            photo = f.absolutePath
        } else if (bytes.isEmpty()) {
            photo?.let { runCatching { File(it).delete() } }
            photo = null
        }
        _s.update { st ->
            st.copy(openInfo = st.openInfo.copy(name = name.ifBlank { st.openInfo.name }, bio = bio, photo = photo))
        }
        persist()
    }

    // ---------------------------------------------------------------- saved chats

    /** Writes the open chat to disk (always the newest state) and refreshes the dashboard list. */
    private fun persist() {
        val s = _s.value
        val addr = s.openAddr
        if (addr.isBlank()) return
        if (s.messages.isEmpty()) {
            ioPool.execute { store.delete(addr) }
            _s.update { st -> st.copy(chats = st.chats.filter { it.address != addr }) }
            return
        }
        if (saveHistory.value) {
            ioPool.execute {
                val st = _s.value
                if (st.openAddr == addr && st.messages.isNotEmpty()) store.save(addr, st.openInfo, st.messages)
            }
        }
        val last = s.messages.last()
        val meta = ChatMeta(addr, s.openInfo.display, Media.previewOf(last), last.time, s.openInfo.photo, Media.tickLevel(last))
        _s.update { st -> st.copy(chats = (st.chats.filter { it.address != addr } + meta).sortedByDescending { it.lastTime }) }
    }

    /** Opens a saved chat from the dashboard. Returns false if the phone is busy with another connection. */
    fun openChat(meta: ChatMeta): Boolean {
        val s = _s.value
        if (s.link == LinkState.CONNECTED && s.openAddr != meta.address) {
            report("Disconnect the current chat before opening another one.")
            return false
        }
        if (s.link == LinkState.CONNECTING || s.link == LinkState.WAITING_PEER) {
            report("Connection in progress. Please wait.")
            return false
        }
        if (s.openAddr != meta.address) {
            val st = store.load(meta.address)
            _s.update {
                it.copy(
                    openAddr = meta.address,
                    openInfo = st?.info ?: ChatInfo(name = meta.name, photo = meta.photo),
                    messages = st?.messages ?: emptyList(),
                    link = LinkState.IDLE, code = "",
                )
            }
        }
        return true
    }

    /** Local nickname for a contact (only on this phone). */
    fun renamePeer(addr: String, nick: String) {
        val n = nick.trim().ifBlank { null }
        if (_s.value.openAddr == addr) {
            _s.update { it.copy(openInfo = it.openInfo.copy(nick = n)) }
            persist()
        } else {
            ioPool.execute {
                val st = store.load(addr) ?: return@execute
                val info = st.info.copy(nick = n)
                store.save(addr, info, st.messages)
                _s.update { s -> s.copy(chats = s.chats.map { if (it.address == addr) it.copy(name = info.display) else it }) }
            }
        }
    }

    private fun ours(f: File): Boolean = runCatching {
        val p = f.canonicalPath
        p.startsWith(receivedDir().canonicalPath) || p.startsWith(app.filesDir.canonicalPath)
    }.getOrDefault(false)

    private fun deleteMedia(m: Msg) {
        m.thumb?.let { runCatching { File(it).delete() } }
        m.savedPath?.let { p -> runCatching { val f = File(p); if (ours(f)) f.delete() } }
    }

    fun deleteMessage(id: Long) {
        val m = _s.value.messages.firstOrNull { it.id == id } ?: return
        if (m.status == Status.TRANSFERRING || m.status == Status.OFFERED) cancelTransfer(id)
        _s.update { s -> s.copy(messages = s.messages.filter { it.id != id }) }
        ioPool.execute { deleteMedia(m) }
        persist()
    }

    /** Deletes the conversation, its thumbnails and the files received in it. */
    fun deleteChat(addr: String) {
        if (addr in pins.value) togglePin(addr)
        if (addr in favs.value) toggleFav(addr)
        if (addr in hiddenChats.value) toggleHide(addr)
        val s = _s.value
        val msgs = if (s.openAddr == addr) s.messages else store.load(addr)?.messages ?: emptyList()
        val photo = if (s.openAddr == addr) s.openInfo.photo else s.chats.firstOrNull { it.address == addr }?.photo
        if (s.openAddr == addr) {
            if (s.link == LinkState.CONNECTED) cleanupTransfers()
            _s.update { it.copy(messages = emptyList(), chats = it.chats.filter { c -> c.address != addr }) }
        } else {
            _s.update { it.copy(chats = it.chats.filter { c -> c.address != addr }) }
        }
        ioPool.execute {
            msgs.forEach { deleteMedia(it) }
            photo?.let { runCatching { File(it).delete() } }
            store.delete(addr)
        }
    }

    fun deleteAllChats() {
        _s.value.chats.map { it.address }.forEach { deleteChat(it) }
    }

    // ---------------------------------------------------------------- discovery

    private val receiver = object : BroadcastReceiver() {
        @Suppress("DEPRECATION")
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val d: BluetoothDevice? =
                        if (Build.VERSION.SDK_INT >= 33)
                            i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                        else i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    if (d != null) addFound(d)
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> _s.update { it.copy(scanning = false) }
            }
        }
    }

    init {
        val f = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
        }
        ContextCompat.registerReceiver(app, receiver, f, ContextCompat.RECEIVER_EXPORTED)
    }

    private fun addFound(d: BluetoothDevice) {
        val dev = Device(d.name ?: "Unknown device", d.address, d.bondState == BluetoothDevice.BOND_BONDED)
        _s.update { s ->
            if (s.devices.any { it.address == dev.address }) s else s.copy(devices = s.devices + dev)
        }
    }

    fun startScan() {
        val a = adapter ?: return report("This phone has no Bluetooth hardware.")
        if (!a.isEnabled) return report("Bluetooth is off. Turn it on first.")
        val paired = a.bondedDevices.map { Device(it.name ?: "Unknown device", it.address, true) }
        _s.update { it.copy(devices = paired, scanning = true) }
        a.cancelDiscovery()
        if (!a.startDiscovery()) {
            _s.update { it.copy(scanning = false) }
            report("Couldn't start scanning. On Android 11 and below, Location must be turned on.")
        }
    }

    fun stopScan() {
        runCatching { adapter?.cancelDiscovery() }
        _s.update { it.copy(scanning = false) }
    }

    // ---------------------------------------------------------------- listening (receiver side)

    fun startListening() {
        val a = adapter ?: return
        if (!a.isEnabled || server != null) return
        val ss = try {
            a.listenUsingRfcommWithServiceRecord("NearChat", APP_UUID)
        } catch (e: Exception) {
            return
        }
        server = ss
        thread(isDaemon = true, name = "nearchat-accept") {
            while (true) {
                val sock = try { ss.accept() } catch (e: Exception) { break }
                handleIncoming(sock)
            }
            if (server === ss) server = null
        }
    }

    private fun handleIncoming(sock: BluetoothSocket) {
        if (conn != null || pendingConn != null) {
            runCatching { sock.close() }
            return
        }
        try {
            val c = Conn.handshake(sock)
            val (t, body) = c.read()
            if (t != T.HELLO) { c.close(); return }
            pendingConn = c
            _s.update { it.copy(incoming = Incoming(String(body, Charsets.UTF_8).take(60), c.code)) }
        } catch (e: Exception) {
            runCatching { sock.close() }
        }
    }

    /** User tapped Accept / Reject on the connection request. */
    fun respondToRequest(accept: Boolean) {
        val c = pendingConn ?: return
        val name = _s.value.incoming?.deviceName ?: "Device"
        pendingConn = null
        _s.update { it.copy(incoming = null) }
        thread {
            try {
                if (accept) {
                    c.send(T.ACCEPT)
                    onConnected(c, name)
                } else {
                    c.send(T.REJECT)
                    c.close()
                }
            } catch (e: IOException) {
                c.close()
                report("The connection dropped while accepting the request.")
            }
        }
    }

    // ---------------------------------------------------------------- connecting (sender side)

    fun connect(d: Device) {
        val a = adapter ?: return
        val st = _s.value.link
        if (st == LinkState.CONNECTING || st == LinkState.WAITING_PEER) return
        val fallback = if (st == LinkState.LOST) LinkState.LOST else LinkState.IDLE
        val my = ++attempt
        a.cancelDiscovery()
        _s.update { it.copy(link = LinkState.CONNECTING, peerName = d.name, scanning = false) }
        thread(name = "nearchat-connect") {
            var sock: BluetoothSocket? = null
            try {
                sock = a.getRemoteDevice(d.address).createRfcommSocketToServiceRecord(APP_UUID)
                connectingSock = sock
                sock.connect()
                val c = Conn.handshake(sock)
                c.send(T.HELLO, deviceName().toByteArray(Charsets.UTF_8))
                _s.update { it.copy(link = LinkState.WAITING_PEER) }
                val (t, _) = c.read()
                if (my != attempt) { c.close(); return@thread }
                if (t == T.ACCEPT) {
                    onConnected(c, d.name)
                } else {
                    c.close()
                    _s.update { it.copy(link = fallback) }
                    report("${d.name} declined the connection.")
                }
            } catch (e: Exception) {
                runCatching { sock?.close() }
                if (my != attempt) return@thread
                _s.update { it.copy(link = fallback) }
                report("Couldn't connect. NearChat must be open and Bluetooth on at the other phone.")
            } finally {
                if (connectingSock === sock) connectingSock = null
            }
        }
    }

    /** Reconnect to the person whose chat is currently open. */
    fun reconnect() {
        val s = _s.value
        if (s.openAddr.isBlank()) return report("Select a device first.")
        connect(Device(s.openInfo.name.ifBlank { s.openInfo.display }, s.openAddr))
    }

    fun disconnect() {
        attempt++
        runCatching { connectingSock?.close() }
        connectingSock = null
        val c = conn
        conn = null
        cleanupTransfers()
        if (c != null) thread { c.close() }
        _s.update { s ->
            s.copy(
                link = LinkState.IDLE, code = "",
                messages = s.messages.map {
                    if (it.status == Status.TRANSFERRING || it.status == Status.OFFERED || it.status == Status.SENDING) it.copy(status = Status.FAILED) else it
                },
            )
        }
        persist()
    }

    private fun onConnected(c: Conn, peer: String) {
        val addr = runCatching { c.socket.remoteDevice.address }.getOrDefault("")
        conn = c
        val stored = if (addr.isNotBlank()) store.load(addr) else null
        val info = stored?.info ?: ChatInfo(name = peer)
        _s.update {
            it.copy(
                link = LinkState.CONNECTED, peerName = peer, code = c.code,
                openAddr = addr, openInfo = info.copy(name = info.name.ifBlank { peer }),
                messages = stored?.messages ?: emptyList(),
            )
        }
        thread(name = "nearchat-read") { readLoop(c) }
        thread { runCatching { sendProfile(c) } }
    }

    private fun onLost(c: Conn) {
        c.close()
        if (conn !== c) return
        conn = null
        cleanupTransfers()
        _s.update { s ->
            s.copy(
                link = LinkState.LOST,
                messages = s.messages.map {
                    if (it.status == Status.TRANSFERRING || it.status == Status.OFFERED || it.status == Status.SENDING) it.copy(status = Status.FAILED) else it
                },
            )
        }
        persist()
    }

    private fun cleanupTransfers() {
        receiving.keys.toList().forEach { closeReceive(it, delete = true) }
        offers.clear(); cancelled.clear()
    }

    // ---------------------------------------------------------------- reading

    private fun readLoop(c: Conn) {
        try {
            while (true) {
                val (t, b) = c.read()
                handle(c, t, b)
            }
        } catch (e: Exception) {
            onLost(c)
        }
    }

    private fun handle(c: Conn, t: Int, b: ByteArray) {
        when (t) {
            T.TEXT -> {
                val id = idOf(b)
                val text = String(b, 8, b.size - 8, Charsets.UTF_8)
                addMsg(Msg(id = id, mine = false, status = Status.DONE, text = text))
                thread { runCatching { c.send(T.ACK, pack(id)) } }
            }
            T.ACK -> {
                val now = System.currentTimeMillis()
                upd(idOf(b)) {
                    it.copy(
                        status = if (it.status == Status.SENT || it.status == Status.SENDING) Status.DELIVERED else it.status,
                        deliveredAt = if (it.deliveredAt == 0L) now else it.deliveredAt,
                    )
                }
            }
            T.OFFER -> {
                val bb = ByteBuffer.wrap(b)
                val id = bb.long
                val size = bb.long
                val name = safeName(String(b, 16, b.size - 16, Charsets.UTF_8))
                offers[id] = name to size
                addMsg(Msg(id = id, mine = false, status = Status.OFFERED, fileName = name, fileSize = size))
                if (Media.isVoice(name) && size in 1..(3L * 1024 * 1024)) respondToOffer(id, true)
            }
            T.FACCEPT -> {
                val id = idOf(b)
                if (cancelled.contains(id)) return
                upd(id) { it.copy(status = Status.TRANSFERRING, progress = 0f) }
                sendPool.execute { streamFile(c, id) }
            }
            T.FREJECT -> {
                val id = idOf(b)
                outgoing.remove(id)
                upd(id) { it.copy(status = Status.REJECTED) }
            }
            T.CHUNK -> onChunk(c, b)
            T.FEND -> onFileEnd(c, idOf(b))
            T.FCANCEL -> {
                val id = idOf(b)
                if (receiving.containsKey(id)) closeReceive(id, delete = true) else cancelled.add(id)
                offers.remove(id)
                upd(id) { if (it.status == Status.DONE) it else it.copy(status = Status.CANCELLED) }
            }
            T.PROFILE -> {
                val din = DataInputStream(ByteArrayInputStream(b))
                val name = din.readUTF().take(25)
                val bio = din.readUTF().take(80)
                val n = din.readInt()
                if (n < 0 || n > 200_000) return
                val bytes = ByteArray(n)
                din.readFully(bytes)
                onPeerProfile(c, name, bio, bytes)
            }
            T.SEEN -> {
                val bb = ByteBuffer.wrap(b)
                val n = bb.int
                if (n < 0 || n > 500) return
                val ids = HashSet<Long>()
                repeat(n) { if (bb.remaining() >= 8) ids.add(bb.long) }
                val now = System.currentTimeMillis()
                _s.update { s ->
                    s.copy(
                        messages = s.messages.map {
                            if (it.mine && it.id in ids) it.copy(seenAt = now, deliveredAt = if (it.deliveredAt == 0L) now else it.deliveredAt) else it
                        },
                    )
                }
                persist()
            }
            T.REACT -> {
                val id = idOf(b)
                val e = String(b, 8, b.size - 8, Charsets.UTF_8).take(8)
                upd(id) { it.copy(theirReact = e.ifEmpty { null }) }
            }
        }
    }

    private fun onChunk(c: Conn, b: ByteArray) {
        val id = idOf(b)
        val out = receiving[id] ?: return
        val size = offers[id]?.second ?: return
        val total = (counts[id] ?: 0L) + (b.size - 8)
        try {
            if (total > size) throw IOException("too much data")
            out.write(b, 8, b.size - 8)
        } catch (e: IOException) {
            closeReceive(id, delete = true)
            upd(id) { it.copy(status = Status.FAILED) }
            report("Couldn't save the file (storage or data error).")
            thread { runCatching { c.send(T.FCANCEL, pack(id)) } }
            return
        }
        counts[id] = total
        val pct = (total * 100 / size).toInt()
        if (lastPct[id] != pct) {
            lastPct[id] = pct
            upd(id, save = false) { it.copy(progress = total.toFloat() / size) }
        }
    }

    private fun onFileEnd(c: Conn, id: Long) {
        val f = paths[id]
        val got = counts[id] ?: 0L
        val size = offers[id]?.second ?: -1L
        val name = offers[id]?.first ?: ""
        closeReceive(id, delete = false)
        offers.remove(id)
        if (f != null && got == size) {
            upd(id) { it.copy(status = Status.DONE, progress = 1f, savedPath = f.absolutePath) }
            thread { runCatching { c.send(T.ACK, pack(id)) } }
            if (Media.isImage(name) || Media.isVideo(name)) {
                ioPool.execute {
                    val bmp = if (Media.isImage(name)) Media.decodeFile(f.absolutePath, 1024)
                    else Media.videoFrame { it.setDataSource(f.absolutePath) }
                    val th = bmp?.let { Media.saveThumb(thumbDir, id, it) }
                    if (th != null) upd(id) { it.copy(thumb = th) }
                }
            }
        } else {
            f?.delete()
            upd(id) { it.copy(status = Status.FAILED) }
        }
    }

    private fun closeReceive(id: Long, delete: Boolean) {
        runCatching { receiving.remove(id)?.close() }
        val f = paths.remove(id)
        if (delete) f?.delete()
        counts.remove(id); lastPct.remove(id)
    }

    // ---------------------------------------------------------------- read receipts and reactions

    /** Tells the other phone which of its messages we have now seen (only while the chat is on screen). */
    fun markSeen() {
        if (!readReceipts.value || !appVisible.value) return
        val c = conn ?: return
        val ids = _s.value.messages.filter { !it.mine && !it.seenAck }.map { it.id }.take(400)
        if (ids.isEmpty()) return
        _s.update { s -> s.copy(messages = s.messages.map { if (it.id in ids) it.copy(seenAck = true) else it }) }
        persist()
        thread {
            val bb = ByteBuffer.allocate(4 + ids.size * 8).putInt(ids.size)
            ids.forEach { bb.putLong(it) }
            runCatching { c.send(T.SEEN, bb.array()) }
        }
    }

    /** React to a message (tap the same emoji again to remove). */
    fun react(id: Long, emoji: String) {
        upd(id) { it.copy(myReact = if (it.myReact == emoji) null else emoji) }
        val now = _s.value.messages.firstOrNull { it.id == id }?.myReact ?: ""
        val c = conn ?: return
        thread { runCatching { c.send(T.REACT, pack(id, now.toByteArray(Charsets.UTF_8))) } }
    }

    // ---------------------------------------------------------------- sending text, stickers, contacts

    fun sendText(text: String) = sendRaw(text)

    fun sendSticker(emoji: String) = sendRaw(Media.STICKER_PREFIX + emoji)

    fun sendContact(name: String, number: String) =
        sendRaw(Media.CONTACT_PREFIX + name.replace('\u0001', ' ') + "\u0001" + number.replace('\u0001', ' '))

    private fun sendRaw(text: String) {
        val c = conn ?: return report("Not connected. Reconnect first.")
        val id = Random.nextLong()
        addMsg(Msg(id = id, mine = true, status = Status.SENDING, text = text))
        thread { pushText(c, id, text) }
    }

    private fun pushText(c: Conn, id: Long, text: String) {
        try {
            c.send(T.TEXT, pack(id, text.toByteArray(Charsets.UTF_8)))
            upd(id) { if (it.status == Status.SENDING) it.copy(status = Status.SENT) else it }
        } catch (e: IOException) {
            upd(id) { it.copy(status = Status.FAILED) }
        }
    }

    // ---------------------------------------------------------------- sending files and voice

    fun describe(uri: Uri): PickedFile? {
        var name = "file"
        var size = -1L
        runCatching {
            app.contentResolver.query(uri, null, null, null, null)?.use { cur ->
                if (cur.moveToFirst()) {
                    val ni = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = cur.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0) name = cur.getString(ni) ?: name
                    if (si >= 0 && !cur.isNull(si)) size = cur.getLong(si)
                }
            }
        }
        if (size <= 0) size = runCatching { app.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } }.getOrNull() ?: -1L
        if (size <= 0) { report("Couldn't read the file size: $name"); return null }
        return PickedFile(uri, name, size)
    }

    fun sendFiles(files: List<PickedFile>, keepPath: String? = null) {
        val c = conn ?: return report("Not connected. Reconnect first.")
        for (f in files) {
            val id = Random.nextLong()
            outgoing[id] = f.uri
            addMsg(Msg(id = id, mine = true, status = Status.OFFERED, fileName = f.name, fileSize = f.size, savedPath = keepPath))
            thread {
                makeSendThumb(id, f)
                pushOffer(c, id, f.name, f.size)
            }
        }
    }

    /** Sends a recorded voice message (the other phone accepts it automatically). */
    fun sendVoice(file: File, secs: Int) {
        voiceDir.mkdirs()
        val dest = File(voiceDir, "v_${System.currentTimeMillis()}.m4a")
        if (!file.renameTo(dest)) {
            runCatching { file.copyTo(dest, true); file.delete() }
        }
        if (!dest.exists()) return report("Couldn't save the voice message.")
        sendFiles(listOf(PickedFile(Uri.fromFile(dest), "voice_${secs}s.m4a", dest.length())), keepPath = dest.absolutePath)
    }

    private fun makeSendThumb(id: Long, f: PickedFile) {
        val bmp = when {
            Media.isImage(f.name) -> Media.decodeStream({ app.contentResolver.openInputStream(f.uri) }, 1024)
            Media.isVideo(f.name) -> Media.videoFrame { it.setDataSource(app, f.uri) }
            else -> null
        } ?: return
        val th = Media.saveThumb(thumbDir, id, bmp)
        upd(id) { it.copy(thumb = th) }
    }

    private fun pushOffer(c: Conn, id: Long, name: String, size: Long) {
        try {
            val nb = name.toByteArray(Charsets.UTF_8)
            c.send(T.OFFER, ByteBuffer.allocate(16 + nb.size).putLong(id).putLong(size).put(nb).array())
        } catch (e: IOException) {
            upd(id) { it.copy(status = Status.FAILED) }
        }
    }

    private fun streamFile(c: Conn, id: Long) {
        val uri = outgoing[id] ?: return
        val size = _s.value.messages.firstOrNull { it.id == id }?.fileSize ?: return
        try {
            val ins = app.contentResolver.openInputStream(uri) ?: throw IOException("cannot open")
            ins.use {
                val buf = ByteArray(CHUNK)
                var total = 0L
                var pct = -1
                while (true) {
                    if (cancelled.remove(id)) return
                    val n = it.read(buf)
                    if (n < 0) break
                    c.send(T.CHUNK, pack(id, buf.copyOf(n)))
                    total += n
                    val p = (total * 100 / size).toInt()
                    if (p != pct) {
                        pct = p
                        upd(id, save = false) { m -> m.copy(progress = (total.toFloat() / size).coerceAtMost(1f)) }
                    }
                }
            }
            c.send(T.FEND, pack(id))
            outgoing.remove(id)
            upd(id) { it.copy(status = Status.DONE, progress = 1f) }
        } catch (e: Exception) {
            upd(id) { if (it.status == Status.CANCELLED) it else it.copy(status = Status.FAILED) }
        }
    }

    // ---------------------------------------------------------------- receiving files (user decision)

    fun respondToOffer(id: Long, accept: Boolean) {
        val c = conn ?: return report("The connection was lost.")
        val (name, size) = offers[id] ?: return
        thread {
            try {
                if (!accept) {
                    offers.remove(id)
                    upd(id) { it.copy(status = Status.REJECTED) }
                    c.send(T.FREJECT, pack(id))
                    return@thread
                }
                val dir = receivedDir()
                if (dir.usableSpace < size + 20L * 1024 * 1024) {
                    offers.remove(id)
                    upd(id) { it.copy(status = Status.FAILED) }
                    report("Not enough storage space for $name.")
                    c.send(T.FREJECT, pack(id))
                    return@thread
                }
                val f = uniqueFile(dir, name)
                paths[id] = f
                counts[id] = 0L
                receiving[id] = FileOutputStream(f)
                upd(id) { it.copy(status = Status.TRANSFERRING, progress = 0f) }
                c.send(T.FACCEPT, pack(id))
            } catch (e: IOException) {
                closeReceive(id, delete = true)
                upd(id) { it.copy(status = Status.FAILED) }
            }
        }
    }

    fun cancelTransfer(id: Long) {
        val c = conn
        if (receiving.containsKey(id)) closeReceive(id, delete = true) else cancelled.add(id)
        offers.remove(id)
        upd(id) { it.copy(status = Status.CANCELLED) }
        if (c != null) thread { runCatching { c.send(T.FCANCEL, pack(id)) } }
    }

    fun retry(id: Long) {
        val c = conn ?: return report("Reconnect first, then retry.")
        val m = _s.value.messages.firstOrNull { it.id == id && it.mine } ?: return
        if (m.text != null) {
            upd(id) { it.copy(status = Status.SENDING) }
            thread { pushText(c, id, m.text) }
        } else if (m.fileName != null && outgoing.containsKey(id)) {
            cancelled.remove(id)
            upd(id) { it.copy(status = Status.OFFERED, progress = 0f) }
            thread { pushOffer(c, id, m.fileName, m.fileSize) }
        } else {
            report("This file can't be resent after the app was closed. Attach it again to send.")
        }
    }

    // ---------------------------------------------------------------- helpers

    private fun safeName(raw: String): String =
        raw.substringAfterLast('/').substringAfterLast('\\')
            .replace(Regex("[^\\p{L}\\p{N}._\\- ]"), "_")
            .trim().trimStart('.').take(100).ifBlank { "file" }

    private fun uniqueFile(dir: File, name: String): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val base = name.substringBeforeLast('.', name)
        val ext = name.substringAfterLast('.', "").let { if (it.isEmpty()) "" else ".$it" }
        var i = 1
        while (f.exists()) { f = File(dir, "$base ($i)$ext"); i++ }
        return f
    }

    fun shutdown() {
        runCatching { app.unregisterReceiver(receiver) }
        runCatching { server?.close() }
        server = null
        runCatching { pendingConn?.close() }
        disconnect()
    }
}
