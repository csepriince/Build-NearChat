package com.nearchat.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nearchat.app.R
import com.nearchat.app.core.Media
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

fun formatSize(b: Long): String = when {
    b < 1024 -> "$b B"
    b < 1024 * 1024 -> "%.1f KB".format(b / 1024.0)
    b < 1024L * 1024 * 1024 -> "%.1f MB".format(b / 1048576.0)
    else -> "%.2f GB".format(b / 1073741824.0)
}

val REACTIONS = listOf("\u2764\uFE0F", "\uD83D\uDE02", "\uD83D\uDE2E", "\uD83D\uDE22", "\uD83D\uDC4D", "\uD83D\uDE4F")

val EMOJIS: List<String> = (
    "\uD83D\uDE00 \uD83D\uDE03 \uD83D\uDE04 \uD83D\uDE01 \uD83D\uDE06 \uD83D\uDE05 \uD83D\uDE02 \uD83E\uDD23 \uD83D\uDE0A \uD83D\uDE07 \uD83D\uDE42 \uD83D\uDE09 " +
        "\uD83D\uDE0D \uD83E\uDD70 \uD83D\uDE18 \uD83D\uDE0B \uD83D\uDE1C \uD83E\uDD2A \uD83D\uDE0E \uD83E\uDD29 \uD83E\uDD73 \uD83D\uDE0F \uD83D\uDE12 \uD83D\uDE1E " +
        "\uD83D\uDE22 \uD83D\uDE2D \uD83D\uDE21 \uD83D\uDE31 \uD83E\uDD14 \uD83E\uDD17 \uD83D\uDC4D \uD83D\uDC4E \uD83D\uDC4F \uD83D\uDE4F \uD83D\uDCAA \uD83E\uDD1D " +
        "\u270C\uFE0F \uD83D\uDC4B \u2764\uFE0F \uD83D\uDC99 \uD83D\uDC9C \uD83D\uDD25 \u2728 \uD83C\uDF89 \uD83D\uDCAF \uD83C\uDF81 \uD83C\uDF82 \u2615 \uD83C\uDF55 \uD83D\uDE80"
    ).split(" ")

val STICKERS: List<String> = (
    "\uD83E\uDD73 \uD83D\uDE0E \uD83E\uDD70 \uD83E\uDD2F \uD83D\uDE34 \uD83E\uDD11 \uD83D\uDC7B \uD83E\uDD16 " +
        "\uD83D\uDC36 \uD83D\uDC31 \uD83E\uDD81 \uD83E\uDD84 \uD83D\uDCA9 \uD83C\uDF89 \uD83D\uDD25 \uD83D\uDC96"
    ).split(" ")

/** Premium 3D button: raised face with a darker lower edge that "presses" down when tapped. */
@Composable
fun GradientButton(
    text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true,
    height: Int = 56, fontSize: Int = 17,
) {
    val shape = RoundedCornerShape((height * 0.36f).dp)
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val depth = 5
    val face = if (enabled) listOf(Color(0xFF8CA0FF), Color(0xFF4F6BFF), Color(0xFF6B3FE8))
    else listOf(Color(0xFFB8BDC9), Color(0xFF9CA3B3), Color(0xFF8A91A3))
    val edge = if (enabled) Color(0xFF2A38A8) else Color(0xFF6F7686)
    Box(modifier.height((height + depth).dp)) {
        Box(Modifier.fillMaxWidth().height(height.dp).align(Alignment.BottomCenter).clip(shape).background(edge))
        Box(
            Modifier.fillMaxWidth().height(height.dp).align(Alignment.TopCenter)
                .offset(y = if (pressed) depth.dp else 0.dp)
                .clip(shape).background(Brush.verticalGradient(face))
                .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                Modifier.fillMaxWidth().height((height / 2).dp).align(Alignment.TopCenter)
                    .background(Brush.verticalGradient(listOf(Color(0x40FFFFFF), Color.Transparent))),
            )
            Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = fontSize.sp)
        }
    }
}

/** Round 3D button (send / mic). */
@Composable
fun Circle3D(size: Int = 50, enabled: Boolean = true, onClick: () -> Unit, content: @Composable () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val depth = 4
    val face = if (enabled) listOf(Color(0xFF8CA0FF), Color(0xFF4F6BFF), Color(0xFF6B3FE8))
    else listOf(Color(0xFFB8BDC9), Color(0xFF9CA3B3), Color(0xFF8A91A3))
    val edge = if (enabled) Color(0xFF2A38A8) else Color(0xFF6F7686)
    Box(Modifier.size(size.dp, (size + depth).dp)) {
        Box(Modifier.size(size.dp).align(Alignment.BottomCenter).clip(CircleShape).background(edge))
        Box(
            Modifier.size(size.dp).align(Alignment.TopCenter)
                .offset(y = if (pressed) depth.dp else 0.dp)
                .clip(CircleShape).background(Brush.verticalGradient(face))
                .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick),
            contentAlignment = Alignment.Center,
        ) { content() }
    }
}

/** Raised square tile used in the attach menu. */
@Composable
fun Tile3D(color: Color, size: Int = 58, content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    val depth = 5
    Box(Modifier.size(size.dp, (size + depth).dp)) {
        Box(Modifier.size(size.dp).align(Alignment.BottomCenter).clip(shape).background(lerp(color, Color.Black, 0.35f)))
        Box(
            Modifier.size(size.dp).align(Alignment.TopCenter).clip(shape)
                .background(Brush.verticalGradient(listOf(lerp(color, Color.White, 0.3f), color))),
            contentAlignment = Alignment.Center,
        ) { content() }
    }
}

/** NearChat logo (circular), with a small reveal animation. */
@Composable
fun LogoMark(size: Int = 44, animate: Boolean = true) {
    val reveal = remember { Animatable(if (animate) 0f else 1f) }
    LaunchedEffect(Unit) { if (animate) reveal.animateTo(1f, tween(900, easing = FastOutSlowInEasing)) }
    Image(
        painter = painterResource(R.drawable.logo),
        contentDescription = "NearChat",
        modifier = Modifier
            .size(size.dp)
            .graphicsLayer {
                alpha = reveal.value
                scaleX = 0.6f + 0.4f * reveal.value
                scaleY = 0.6f + 0.4f * reveal.value
                rotationZ = (1f - reveal.value) * -25f
            }
            .clip(CircleShape),
    )
}

/** Round avatar: the person's photo when we have one, otherwise the first letter of the name. */
@Composable
fun Avatar(name: String, size: Int = 52, online: Boolean = false, photo: String? = null) {
    val bmp = rememberBitmap(photo, size * 3)
    Box(Modifier.size(size.dp)) {
        if (bmp != null) {
            Image(bmp, name, Modifier.fillMaxSize().clip(CircleShape), contentScale = ContentScale.Crop)
        } else {
            Box(Modifier.fillMaxSize().clip(CircleShape).background(brand), contentAlignment = Alignment.Center) {
                Text(
                    name.trim().take(1).uppercase().ifBlank { "?" },
                    color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size * 0.42f).sp,
                )
            }
        }
        if (online) Box(Modifier.align(Alignment.BottomEnd)) { StatusDot(true, 13) }
    }
}

/** Chat background: gradient preset or the user's own photo (dimmed in dark mode). */
@Composable
fun WallpaperLayer(wall: Int, path: String?, modifier: Modifier = Modifier) {
    val dark = LocalDark.current
    val bmp = if (wall >= Wallpapers.size) rememberBitmap(path, 1280) else null
    Box(modifier) {
        if (bmp != null) {
            Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Box(Modifier.fillMaxSize().background(wallBrush(wall)))
        }
        if (dark) Box(Modifier.fillMaxSize().background(Color(0xB3000000)))
    }
}

/** Lightweight radar: pulsing rings drawn on a Canvas, no heavy rendering. */
@Composable
fun Radar(modifier: Modifier = Modifier, active: Boolean, size: Int = 220) {
    val t = rememberInfiniteTransition(label = "radar")
    val p by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(if (active) 1500 else 3500, easing = LinearEasing), RepeatMode.Restart),
        label = "p",
    )
    Box(modifier.size(size.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val maxR = this.size.minDimension / 2
            for (i in 0..2) {
                val f = (p + i / 3f) % 1f
                drawCircle(
                    color = Electric.copy(alpha = (1f - f) * 0.35f),
                    radius = maxR * (0.3f + 0.7f * f),
                    style = Stroke(width = 3.dp.toPx()),
                )
            }
            drawCircle(brush = Brush.linearGradient(listOf(Electric, Violet)), radius = maxR * 0.28f)
        }
        Icon(Icons.Default.Bluetooth, null, tint = Color.White, modifier = Modifier.size((size * 0.15f).dp))
    }
}

@Composable
fun StatusDot(on: Boolean, size: Int = 10) {
    Box(Modifier.size(size.dp).clip(CircleShape).background(if (on) Online else Offline))
}

/** Decodes an image file off the main thread. */
@Composable
fun rememberBitmap(path: String?, maxDim: Int): ImageBitmap? {
    val state = produceState<ImageBitmap?>(initialValue = null, path, maxDim) {
        value = if (path == null) null else withContext(Dispatchers.IO) { Media.decodeFile(path, maxDim)?.asImageBitmap() }
    }
    return state.value
}
