@file:Suppress("DEPRECATION")

package com.nearchat.app.core

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

object Media {
    const val STICKER_PREFIX = "\u0001S\u0001"
    const val CONTACT_PREFIX = "\u0001C\u0001"

    private val IMG = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif")
    private val VID = setOf("mp4", "mkv", "3gp", "webm", "mov", "avi", "m4v")

    private fun ext(n: String) = n.substringAfterLast('.', "").lowercase()
    fun isImage(n: String) = ext(n) in IMG
    fun isVideo(n: String) = ext(n) in VID
    fun isVoice(n: String) = n.startsWith("voice_") && n.endsWith(".m4a")
    fun voiceSecs(n: String): Int = Regex("voice_(\\d+)s").find(n)?.groupValues?.get(1)?.toIntOrNull() ?: 0
    fun fmtSecs(s: Int): String = "${s / 60}:${(s % 60).toString().padStart(2, '0')}"

    fun stickerOf(t: String?): String? = if (t != null && t.startsWith(STICKER_PREFIX)) t.removePrefix(STICKER_PREFIX) else null

    fun contactOf(t: String?): Pair<String, String>? {
        if (t == null || !t.startsWith(CONTACT_PREFIX)) return null
        val p = t.removePrefix(CONTACT_PREFIX).split('\u0001', limit = 2)
        return if (p.size == 2) p[0] to p[1] else null
    }

    /** 0 none, 1 sent, 2 delivered, 3 seen (only for messages we sent). */
    fun tickLevel(m: Msg): Int {
        if (!m.mine) return 0
        return when {
            m.seenAt > 0 -> 3
            m.deliveredAt > 0 -> 2
            m.status == Status.SENT || m.status == Status.DELIVERED || m.status == Status.DONE -> 1
            else -> 0
        }
    }

    fun previewOf(m: Msg): String {
        val t = m.text
        if (t != null) {
            if (stickerOf(t) != null) return "Sticker"
            val c = contactOf(t)
            if (c != null) return "\uD83D\uDC64 ${c.first}"
            return t
        }
        val n = m.fileName ?: ""
        return when {
            isVoice(n) -> "\uD83C\uDFA4 Voice message ${fmtSecs(voiceSecs(n))}"
            isImage(n) -> "\uD83D\uDCF7 Photo"
            isVideo(n) -> "\uD83C\uDFAC Video"
            else -> "\uD83D\uDCC4 ${m.fileName ?: "File"}"
        }
    }

    private fun sampleFor(o: BitmapFactory.Options, maxDim: Int): Int {
        var s = 1
        while (o.outWidth / (s * 2) >= maxDim && o.outHeight / (s * 2) >= maxDim) s *= 2
        return s
    }

    private fun rotationOf(orientation: Int): Float = when (orientation) {
        ExifInterface.ORIENTATION_ROTATE_90 -> 90f
        ExifInterface.ORIENTATION_ROTATE_180 -> 180f
        ExifInterface.ORIENTATION_ROTATE_270 -> 270f
        else -> 0f
    }

    private fun rotate(b: Bitmap?, deg: Float): Bitmap? {
        if (b == null || deg == 0f) return b
        return Bitmap.createBitmap(b, 0, 0, b.width, b.height, Matrix().apply { postRotate(deg) }, true)
    }

    fun decodeFile(path: String, maxDim: Int): Bitmap? = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, o)
        if (o.outWidth <= 0) null else {
            val bmp = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sampleFor(o, maxDim) })
            val rot = runCatching { rotationOf(ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) }.getOrDefault(0f)
            rotate(bmp, rot)
        }
    } catch (e: Throwable) {
        null
    }

    fun decodeStream(open: () -> InputStream?, maxDim: Int): Bitmap? = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        open()?.use { BitmapFactory.decodeStream(it, null, o) }
        if (o.outWidth <= 0) null else {
            val bmp = open()?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sampleFor(o, maxDim) }) }
            val rot = runCatching {
                open()?.use { rotationOf(ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) } ?: 0f
            }.getOrDefault(0f)
            rotate(bmp, rot)
        }
    } catch (e: Throwable) {
        null
    }

    /** Center-cropped square bitmap (used for profile photos). */
    fun squareBitmap(open: () -> InputStream?, size: Int): Bitmap? = try {
        val b = decodeStream(open, size)
        if (b == null) null else {
            val s = minOf(b.width, b.height)
            val sq = Bitmap.createBitmap(b, (b.width - s) / 2, (b.height - s) / 2, s, s)
            Bitmap.createScaledBitmap(sq, size, size, true)
        }
    } catch (e: Throwable) {
        null
    }

    fun videoFrame(setSource: (android.media.MediaMetadataRetriever) -> Unit): Bitmap? = try {
        val r = android.media.MediaMetadataRetriever()
        try {
            setSource(r)
            r.getFrameAtTime(0)
        } finally {
            r.release()
        }
    } catch (e: Throwable) {
        null
    }

    fun saveThumb(dir: File, id: Long, bmp: Bitmap): String {
        dir.mkdirs()
        val f = File(dir, "$id.jpg")
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 80, it) }
        return f.absolutePath
    }
}
