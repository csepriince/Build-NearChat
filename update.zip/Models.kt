package com.nearchat.app.core

import android.net.Uri

enum class LinkState { IDLE, CONNECTING, WAITING_PEER, CONNECTED, LOST }

enum class Status { SENDING, SENT, DELIVERED, OFFERED, TRANSFERRING, DONE, REJECTED, FAILED, CANCELLED }

data class Device(val name: String, val address: String, val paired: Boolean = false)

data class Incoming(val deviceName: String, val code: String)

data class PickedFile(val uri: Uri, val name: String, val size: Long)

data class Msg(
    val id: Long,
    val mine: Boolean,
    val status: Status,
    val text: String? = null,
    val fileName: String? = null,
    val fileSize: Long = 0,
    val time: Long = System.currentTimeMillis(),
    val progress: Float = 0f,
    val savedPath: String? = null,
    val thumb: String? = null,
    val deliveredAt: Long = 0,
    val seenAt: Long = 0,
    val myReact: String? = null,
    val theirReact: String? = null,
    val seenAck: Boolean = false,
)

/** What we know about the person on the other phone (name/bio/photo come from their profile). */
data class ChatInfo(
    val name: String = "",
    val nick: String? = null,
    val bio: String = "",
    val photo: String? = null,
) {
    val display: String get() = nick?.takeIf { it.isNotBlank() } ?: name
}

/** One row of the chat-list dashboard. lastTick: 0 none, 1 sent, 2 delivered, 3 seen. */
data class ChatMeta(
    val address: String,
    val name: String,
    val lastText: String,
    val lastTime: Long,
    val photo: String? = null,
    val lastTick: Int = 0,
)

data class StoredChat(val address: String, val info: ChatInfo, val messages: List<Msg>)

/** The user's own profile (shown to the other phone after connecting). */
data class Profile(val name: String = "", val bio: String = "", val photo: String? = null)

data class UiState(
    val link: LinkState = LinkState.IDLE,
    val peerName: String = "",
    val code: String = "",
    val scanning: Boolean = false,
    val devices: List<Device> = emptyList(),
    val chats: List<ChatMeta> = emptyList(),
    val openAddr: String = "",
    val openInfo: ChatInfo = ChatInfo(),
    val incoming: Incoming? = null,
    val messages: List<Msg> = emptyList(),
    val error: String? = null,
)
