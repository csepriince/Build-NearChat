package com.nearchat.app.core

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File

/** Records a voice message to an .m4a (AAC) file in the cache folder. */
class VoiceRecorder(private val ctx: Context) {
    private var rec: MediaRecorder? = null
    private var file: File? = null
    private var startedAt = 0L

    fun start(): Boolean {
        return try {
            val f = File(ctx.cacheDir, "rec_${System.currentTimeMillis()}.m4a")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else @Suppress("DEPRECATION") MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(48_000)
            r.setAudioSamplingRate(22_050)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            rec = r
            file = f
            startedAt = System.currentTimeMillis()
            true
        } catch (e: Exception) {
            runCatching { rec?.release() }
            rec = null
            false
        }
    }

    /** Stops recording. Returns the file and its length in seconds, or null if cancelled / too short. */
    fun stop(keep: Boolean): Pair<File, Int>? {
        val r = rec ?: return null
        rec = null
        val f = file
        val secs = ((System.currentTimeMillis() - startedAt) / 1000).toInt()
        try {
            r.stop()
        } catch (e: Exception) {
            runCatching { r.release() }
            f?.delete()
            return null
        }
        runCatching { r.release() }
        if (!keep || f == null || secs < 1) {
            f?.delete()
            return null
        }
        return f to secs
    }
}

/** Plays one voice message at a time. */
object VoicePlayer {
    private var mp: MediaPlayer? = null
    val playing = MutableStateFlow<Long?>(null)
    val progress = MutableStateFlow(0f)

    fun toggle(id: Long, path: String) {
        if (playing.value == id) {
            stop()
            return
        }
        stop()
        try {
            val p = MediaPlayer()
            p.setDataSource(path)
            p.prepare()
            p.setOnCompletionListener { stop() }
            p.start()
            mp = p
            playing.value = id
        } catch (e: Exception) {
            stop()
        }
    }

    fun tick() {
        val p = mp ?: return
        val d = p.duration
        if (d > 0) progress.value = p.currentPosition.toFloat() / d
    }

    fun stop() {
        runCatching { mp?.stop() }
        runCatching { mp?.release() }
        mp = null
        playing.value = null
        progress.value = 0f
    }
}
