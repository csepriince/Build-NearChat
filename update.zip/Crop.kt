package com.nearchat.app.ui

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.nearchat.app.core.Media
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Full-screen square cropper: drag to move, pinch or slide to zoom, then Done. */
@Composable
fun CropDialog(uri: Uri, onDone: (Bitmap) -> Unit, onCancel: () -> Unit) {
    val ctx = LocalContext.current
    val loaded = produceState<Bitmap?>(initialValue = null, uri) {
        value = withContext(Dispatchers.IO) { Media.decodeStream({ ctx.contentResolver.openInputStream(uri) }, 1600) }
    }
    val bmp = loaded.value
    val frame = (LocalConfiguration.current.screenWidthDp - 32).coerceAtLeast(200)
    var zoom by remember { mutableStateOf(1f) }
    var cx by remember { mutableStateOf(0f) }
    var cy by remember { mutableStateOf(0f) }
    LaunchedEffect(bmp) {
        if (bmp != null) {
            cx = bmp.width / 2f
            cy = bmp.height / 2f
            zoom = 1f
        }
    }
    Dialog(onDismissRequest = onCancel, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Color.Black) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = onCancel) { Text("Cancel", color = Color.White) }
                    Text("Crop photo", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(top = 10.dp))
                    TextButton(
                        enabled = bmp != null,
                        onClick = {
                            bmp?.let { b ->
                                val minSide = minOf(b.width, b.height)
                                val side = (minSide / zoom).toInt().coerceIn(1, minSide)
                                val sx = (cx - side / 2f).toInt().coerceIn(0, b.width - side)
                                val sy = (cy - side / 2f).toInt().coerceIn(0, b.height - side)
                                val region = Bitmap.createBitmap(b, sx, sy, side, side)
                                onDone(Bitmap.createScaledBitmap(region, 384, 384, true))
                            }
                        },
                    ) { Text("Done", color = Color(0xFF8FA2FF), fontWeight = FontWeight.Bold) }
                }
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    if (bmp == null) {
                        CircularProgressIndicator(color = Color.White)
                    } else {
                        val img = remember(bmp) { bmp.asImageBitmap() }
                        Canvas(
                            Modifier.size(frame.dp).pointerInput(bmp) {
                                detectTransformGestures { _, pan, z, _ ->
                                    val minSide = minOf(bmp.width, bmp.height).toFloat()
                                    zoom = (zoom * z).coerceIn(1f, 6f)
                                    val side = minSide / zoom
                                    val k = side / size.width
                                    cx = (cx - pan.x * k).coerceIn(side / 2f, bmp.width - side / 2f)
                                    cy = (cy - pan.y * k).coerceIn(side / 2f, bmp.height - side / 2f)
                                }
                            },
                        ) {
                            val minSide = minOf(bmp.width, bmp.height).toFloat()
                            val side = minSide / zoom
                            val sx = (cx - side / 2f).coerceIn(0f, bmp.width - side)
                            val sy = (cy - side / 2f).coerceIn(0f, bmp.height - side)
                            drawImage(
                                img,
                                srcOffset = IntOffset(sx.toInt(), sy.toInt()),
                                srcSize = IntSize(side.toInt().coerceAtLeast(1), side.toInt().coerceAtLeast(1)),
                                dstOffset = IntOffset.Zero,
                                dstSize = IntSize(size.width.toInt(), size.height.toInt()),
                            )
                            val circle = Path().apply { addOval(Rect(Offset.Zero, size)) }
                            clipPath(circle, clipOp = ClipOp.Difference) { drawRect(Color(0xAA000000)) }
                            drawCircle(Color.White, radius = size.minDimension / 2f, style = Stroke(2.dp.toPx()))
                        }
                    }
                }
                Slider(
                    value = zoom, valueRange = 1f..6f, enabled = bmp != null,
                    onValueChange = { z ->
                        zoom = z
                        if (bmp != null) {
                            val side = minOf(bmp.width, bmp.height) / z
                            cx = cx.coerceIn(side / 2f, bmp.width - side / 2f)
                            cy = cy.coerceIn(side / 2f, bmp.height - side / 2f)
                        }
                    },
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp),
                )
            }
        }
    }
}
