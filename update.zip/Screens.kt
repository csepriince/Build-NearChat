@file:OptIn(ExperimentalMaterial3Api::class)

package com.nearchat.app.ui

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.nearchat.app.core.BtController
import com.nearchat.app.core.ChatMeta
import com.nearchat.app.core.Device
import com.nearchat.app.core.LinkState
import com.nearchat.app.core.Media
import com.nearchat.app.core.Msg
import com.nearchat.app.core.PickedFile
import com.nearchat.app.core.Profile
import com.nearchat.app.core.Status
import com.nearchat.app.core.UiState
import com.nearchat.app.core.VoicePlayer
import com.nearchat.app.core.VoiceRecorder
import kotlinx.coroutines.delay
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val timeFmt = SimpleDateFormat("hh:mm a", Locale.getDefault())
private val dayFmt = SimpleDateFormat("dd MMM", Locale.getDefault())

private fun listTime(t: Long): String {
    val a = Calendar.getInstance().apply { timeInMillis = t }
    val b = Calendar.getInstance()
    val same = a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)
    return if (same) timeFmt.format(Date(t)) else dayFmt.format(Date(t))
}

@Composable
fun ActionRow(icon: ImageVector, text: String, color: Color = Color.Unspecified, onClick: () -> Unit) {
    val tint = if (color == Color.Unspecified) MaterialTheme.colorScheme.onSurface else color
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = tint)
        Spacer(Modifier.size(16.dp))
        Text(text, color = tint, fontSize = 16.sp)
    }
}

/** Tick marks after the time of a message we sent: sent, delivered, seen (blue). */
@Composable
private fun Ticks(m: Msg) {
    val gray = tickGray()
    val blue = seenBlue()
    when {
        m.status == Status.FAILED -> Text(" !", color = Offline, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        m.status == Status.SENDING -> Text(" \u2026", color = gray, fontSize = 12.sp)
        else -> when (Media.tickLevel(m)) {
            1 -> Text(" \u2713", color = gray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            2 -> Text(" \u2713\u2713", color = gray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            3 -> Text(" \u2713\u2713", color = blue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            else -> {}
        }
    }
}

// ============================================================ CHATS (dashboard)

@Composable
fun HomeScreen(
    s: UiState,
    profile: Profile,
    onFind: () -> Unit,
    onProfile: () -> Unit,
    onOpenConnected: () -> Unit,
    onOpen: (ChatMeta) -> Unit,
    onDelete: (ChatMeta) -> Unit,
    onRename: (ChatMeta) -> Unit,
) {
    val connected = s.link == LinkState.CONNECTED
    var menuFor by remember { mutableStateOf<ChatMeta?>(null) }
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            LogoMark(44)
            Spacer(Modifier.size(12.dp))
            Column(Modifier.weight(1f)) {
                Text("NearChat", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Private. Local. Offline.", fontSize = 12.sp, color = dim)
            }
            Box(Modifier.clip(CircleShape).clickable(onClick = onProfile)) {
                Avatar(profile.name.ifBlank { "Me" }, 40, photo = profile.photo)
            }
        }
        if (connected) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).clip(RoundedCornerShape(16.dp))
                    .background(Online.copy(alpha = 0.14f)).clickable(onClick = onOpenConnected).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                StatusDot(true)
                Spacer(Modifier.size(10.dp))
                Text("Connected to ${s.openInfo.display.ifBlank { s.peerName }}", fontWeight = FontWeight.Medium)
            }
        }
        if (s.chats.isEmpty()) {
            Column(
                Modifier.weight(1f).fillMaxWidth().padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
            ) {
                LogoMark(110, animate = false)
                Spacer(Modifier.height(14.dp))
                Text("No chats yet", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = dim)
            }
        } else {
            LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                items(s.chats, key = { it.address }) { m ->
                    ChatRow(m, online = connected && s.openAddr == m.address, onClick = { onOpen(m) }, onLong = { menuFor = m })
                    HorizontalDivider(Modifier.padding(start = 84.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                }
            }
        }
        GradientButton("Find Nearby Devices", onFind, Modifier.fillMaxWidth().padding(16.dp))
    }
    menuFor?.let { m ->
        ModalBottomSheet(onDismissRequest = { menuFor = null }) {
            Column(Modifier.padding(bottom = 24.dp)) {
                Text(m.name, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp))
                ActionRow(Icons.Default.Edit, "Rename") { menuFor = null; onRename(m) }
                ActionRow(Icons.Default.Delete, "Delete chat", Offline) { menuFor = null; onDelete(m) }
            }
        }
    }
}

@Composable
private fun ChatRow(m: ChatMeta, online: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    Row(
        Modifier.fillMaxWidth()
            .pointerInput(m.address) { detectTapGestures(onTap = { onClick() }, onLongPress = { onLong() }) }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Avatar(m.name, 52, online, m.photo)
        Spacer(Modifier.size(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(m.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Text(listTime(m.lastTime), fontSize = 12.sp, color = dim)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                when (m.lastTick) {
                    1 -> Text("\u2713 ", color = tickGray(), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    2 -> Text("\u2713\u2713 ", color = tickGray(), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    3 -> Text("\u2713\u2713 ", color = seenBlue(), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    else -> {}
                }
                Text(m.lastText.replace('\n', ' '), maxLines = 1, overflow = TextOverflow.Ellipsis, color = dim, fontSize = 14.sp)
            }
        }
    }
}

// ============================================================ NEARBY

@Composable
fun DeviceCard(d: Device, action: String, onClick: () -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Default.Bluetooth, null, tint = Electric) }
            Spacer(Modifier.size(12.dp))
            Column(Modifier.weight(1f)) {
                Text(d.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    (if (d.paired) "Paired \u2022 " else "") + "Bluetooth \u2022 " + d.address,
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Button(onClick = onClick, shape = RoundedCornerShape(14.dp)) { Text(action) }
        }
    }
}

@Composable
fun NearbyScreen(
    s: UiState,
    onRescan: () -> Unit,
    onVisible: () -> Unit,
    onConnect: (Device) -> Unit,
    onCancel: () -> Unit,
) {
    val busy = s.link == LinkState.CONNECTING || s.link == LinkState.WAITING_PEER
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Nearby devices", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = onRescan, enabled = !s.scanning && !busy) { Text("Rescan") }
        }
        if (busy) {
            Column(Modifier.fillMaxWidth().padding(vertical = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Radar(active = true, size = 160)
                Text(
                    if (s.link == LinkState.CONNECTING) "Connecting to ${s.peerName}\u2026" else "Waiting for ${s.peerName} to accept\u2026",
                    fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp),
                )
                TextButton(onClick = onCancel) { Text("Cancel") }
            }
            return@Column
        }
        if (s.scanning) {
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Radar(active = true, size = 56)
                Spacer(Modifier.size(12.dp))
                Text("Scanning\u2026", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
            items(s.devices, key = { it.address }) { d -> DeviceCard(d, "Connect") { onConnect(d) } }
            if (s.devices.isEmpty() && !s.scanning) {
                item { Text("No devices found", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 24.dp)) }
            }
        }
        OutlinedButton(onClick = onVisible, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(16.dp)) {
            Text("Make my phone visible (5 min)")
        }
    }
}

// ============================================================ CHAT

private fun readContact(ctx: Context, uri: Uri): Pair<String, String>? = runCatching {
    ctx.contentResolver.query(
        uri,
        arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
        null, null, null,
    )?.use { c ->
        if (c.moveToFirst()) Pair(c.getString(0) ?: "", c.getString(1) ?: "") else null
    }
}.getOrNull()

@Composable
fun ChatScreen(
    s: UiState,
    ctl: BtController,
    onBack: () -> Unit,
    onContactInfo: () -> Unit,
    onWallpaper: () -> Unit,
    onReconnect: () -> Unit,
) {
    val ctx = LocalContext.current
    val fontLevel by ctl.fontLevel.collectAsState()
    val wall by ctl.wall.collectAsState()
    val wallPath by ctl.wallPath.collectAsState()
    val visible by ctl.appVisible.collectAsState()
    val fs = when (fontLevel) { 0 -> 14; 2 -> 19; else -> 16 }
    val connected = s.link == LinkState.CONNECTED
    val title = s.openInfo.display.ifBlank { s.peerName }
    val dim = MaterialTheme.colorScheme.onSurfaceVariant

    var input by remember { mutableStateOf("") }
    var pending by remember { mutableStateOf<List<PickedFile>>(emptyList()) }
    var menu by remember { mutableStateOf(false) }
    var sheet by remember { mutableStateOf("") } // "", "attach", "emoji", "msg"
    var emojiTab by remember { mutableStateOf(0) }
    var selId by remember { mutableStateOf<Long?>(null) }
    var infoId by remember { mutableStateOf<Long?>(null) }
    var delId by remember { mutableStateOf<Long?>(null) }
    var delChat by remember { mutableStateOf(false) }
    var viewId by remember { mutableStateOf<Long?>(null) }
    var recording by remember { mutableStateOf(false) }
    var recSecs by remember { mutableStateOf(0) }
    val recents = remember { mutableStateListOf<String>() }
    val recorder = remember { VoiceRecorder(ctx) }
    var camUri by remember { mutableStateOf<Uri?>(null) }

    fun beginRec() {
        if (recorder.start()) { recSecs = 0; recording = true } else ctl.report("Recording start nahi ho payi.")
    }

    val pickMedia = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { uris ->
        pending = pending + uris.mapNotNull { ctl.describe(it) }
    }
    val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        pending = pending + uris.mapNotNull { ctl.describe(it) }
    }
    val takePic = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = camUri
        if (ok && u != null) ctl.describe(u)?.let { ctl.sendFiles(listOf(it)) }
    }
    val pickContact = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val u = r.data?.data
        if (u != null) readContact(ctx, u)?.let { (n, num) -> ctl.sendContact(n, num) }
    }
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) beginRec() else ctl.report("Voice message ke liye Microphone permission chahiye.")
    }

    fun launchCamera() {
        try {
            val dir = File(ctx.cacheDir, "camera").apply { mkdirs() }
            val f = File(dir, "IMG_${System.currentTimeMillis()}.jpg")
            val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
            camUri = uri
            takePic.launch(uri)
        } catch (e: Exception) {
            ctl.report("Camera khul nahi paya.")
        }
    }

    fun startMic() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) beginRec()
        else micPerm.launch(Manifest.permission.RECORD_AUDIO)
    }

    val list = rememberLazyListState()
    LaunchedEffect(s.messages.size) { if (s.messages.isNotEmpty()) list.animateScrollToItem(s.messages.lastIndex) }
    LaunchedEffect(s.messages.size, connected, visible) { if (connected && visible) ctl.markSeen() }
    LaunchedEffect(recording) { while (recording) { delay(1000); recSecs++ } }
    DisposableEffect(Unit) {
        onDispose {
            VoicePlayer.stop()
            if (recording) recorder.stop(false)
        }
    }

    val selMsg = s.messages.firstOrNull { it.id == selId }
    val lastMineId = s.messages.lastOrNull { it.mine }?.id

    Box(Modifier.fillMaxSize()) {
        WallpaperLayer(wall, wallPath, Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize()) {
            // header
            Row(
                Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.background).padding(horizontal = 6.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                Row(Modifier.weight(1f).clickable(onClick = onContactInfo), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(title, 40, connected, s.openInfo.photo)
                    Spacer(Modifier.size(10.dp))
                    Column {
                        Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            if (connected) "Connected \u2022 Bluetooth \u2022 Code ${s.code}" else "Not connected",
                            fontSize = 12.sp, color = dim, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "More") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Contact info") }, onClick = { menu = false; onContactInfo() })
                        DropdownMenuItem(text = { Text("Wallpaper") }, onClick = { menu = false; onWallpaper() })
                        if (connected) DropdownMenuItem(text = { Text("Disconnect") }, onClick = { menu = false; ctl.disconnect(); onBack() })
                        DropdownMenuItem(text = { Text("Delete chat") }, onClick = { menu = false; delChat = true })
                    }
                }
            }
            if (!connected) {
                val busy = s.link == LinkState.CONNECTING || s.link == LinkState.WAITING_PEER
                Row(
                    Modifier.fillMaxWidth().background(Offline.copy(alpha = 0.14f)).padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        if (busy) "Connecting\u2026" else "Connection lost. Reconnect karne ki koshish karein.",
                        modifier = Modifier.weight(1f), fontSize = 14.sp,
                    )
                    if (!busy) TextButton(onClick = onReconnect) { Text("Reconnect") }
                }
            }
            // messages
            LazyColumn(
                state = list, modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(s.messages, key = { it.id }) { m ->
                    Bubble(
                        m, fs, ctl, isLastMine = m.id == lastMineId,
                        onMenu = { selId = m.id; sheet = "msg" },
                        onOpenMedia = { viewId = m.id },
                    )
                }
            }
            // pending files preview
            if (pending.isNotEmpty()) {
                Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.background).padding(horizontal = 12.dp, vertical = 4.dp)) {
                    pending.forEach { f ->
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 2.dp).clip(RoundedCornerShape(14.dp))
                                .background(MaterialTheme.colorScheme.surface).padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(Icons.Default.Description, null, tint = Electric)
                            Spacer(Modifier.size(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                                Text(formatSize(f.size), fontSize = 12.sp, color = dim)
                            }
                            IconButton(onClick = { pending = pending - f }) { Icon(Icons.Default.Close, "Remove") }
                        }
                    }
                }
            }
            // composer / recording bar
            if (recording) {
                Row(
                    Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.background).padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = { recorder.stop(false); recording = false }) { Icon(Icons.Default.Delete, "Cancel", tint = Offline) }
                    Box(Modifier.size(11.dp).clip(CircleShape).background(Offline))
                    Spacer(Modifier.size(8.dp))
                    Text(Media.fmtSecs(recSecs), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Box(
                        Modifier.size(50.dp).clip(CircleShape).background(brand).clickable {
                            val r = recorder.stop(true)
                            recording = false
                            if (r != null) ctl.sendVoice(r.first, r.second)
                        },
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.AutoMirrored.Filled.Send, "Send voice", tint = Color.White) }
                }
            } else {
                Row(
                    Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.background).padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    TextField(
                        value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                        placeholder = { Text("Message") }, maxLines = 4, shape = RoundedCornerShape(26.dp),
                        enabled = connected,
                        leadingIcon = {
                            IconButton(onClick = { sheet = "emoji" }, enabled = connected) { Icon(Icons.Default.EmojiEmotions, "Emoji") }
                        },
                        trailingIcon = {
                            Row {
                                IconButton(onClick = { sheet = "attach" }, enabled = connected) { Icon(Icons.Default.AttachFile, "Attach") }
                                if (input.isBlank() && pending.isEmpty()) {
                                    IconButton(onClick = { launchCamera() }, enabled = connected) { Icon(Icons.Default.CameraAlt, "Camera") }
                                }
                            }
                        },
                        colors = TextFieldDefaults.colors(
                            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                            disabledIndicatorColor = Color.Transparent,
                            focusedContainerColor = MaterialTheme.colorScheme.surface, unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                            disabledContainerColor = MaterialTheme.colorScheme.surface,
                        ),
                    )
                    Spacer(Modifier.size(8.dp))
                    val hasContent = input.isNotBlank() || pending.isNotEmpty()
                    Box(
                        Modifier.size(50.dp).clip(CircleShape)
                            .background(if (connected) brand else Brush.horizontalGradient(listOf(Color.Gray, Color.Gray)))
                            .clickable(enabled = connected) {
                                if (hasContent) {
                                    if (pending.isNotEmpty()) { ctl.sendFiles(pending); pending = emptyList() }
                                    if (input.isNotBlank()) { ctl.sendText(input.trim().take(20000)); input = "" }
                                } else startMic()
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        if (hasContent) Icon(Icons.AutoMirrored.Filled.Send, "Send", tint = Color.White)
                        else Icon(Icons.Default.Mic, "Voice message", tint = Color.White)
                    }
                }
            }
        }
    }

    // ---- attach sheet
    if (sheet == "attach") {
        ModalBottomSheet(onDismissRequest = { sheet = "" }) {
            Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                Row(Modifier.fillMaxWidth()) {
                    AttachTile(Icons.Default.CameraAlt, "Camera", Color(0xFFEF4444)) { sheet = ""; launchCamera() }
                    AttachTile(Icons.Default.Image, "Photos & Videos", Color(0xFF8B5CF6)) {
                        sheet = ""
                        pickMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                    }
                    AttachTile(Icons.Default.Description, "Document", Color(0xFF3B82F6)) { sheet = ""; pickFiles.launch("application/pdf") }
                }
                Row(Modifier.fillMaxWidth()) {
                    AttachTile(Icons.Default.Audiotrack, "Audio", Color(0xFFF59E0B)) { sheet = ""; pickFiles.launch("audio/*") }
                    AttachTile(Icons.Default.Contacts, "Contact", Color(0xFF10B981)) {
                        sheet = ""
                        pickContact.launch(Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI))
                    }
                    AttachTile(Icons.Default.Folder, "Any file", Color(0xFF64748B)) { sheet = ""; pickFiles.launch("*/*") }
                }
            }
        }
    }

    // ---- emoji / sticker sheet
    if (sheet == "emoji") {
        ModalBottomSheet(onDismissRequest = { sheet = "" }) {
            Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
                Row(Modifier.padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Emoji", "Stickers", "Recent").forEachIndexed { i, t ->
                        FilterChip(selected = emojiTab == i, onClick = { emojiTab = i }, label = { Text(t) })
                    }
                }
                val pickEmoji: (String) -> Unit = { e ->
                    input += e
                    recents.remove(e)
                    recents.add(0, e)
                    if (recents.size > 16) recents.removeAt(16)
                }
                when (emojiTab) {
                    0 -> EmojiGrid(EMOJIS, pickEmoji)
                    1 -> StickerGrid(STICKERS) { e -> ctl.sendSticker(e); sheet = "" }
                    else -> if (recents.isEmpty()) Text("No recent emoji", color = dim, modifier = Modifier.padding(vertical = 24.dp)) else EmojiGrid(recents.toList(), pickEmoji)
                }
            }
        }
    }

    // ---- message menu
    if (sheet == "msg" && selMsg != null) {
        ModalBottomSheet(onDismissRequest = { sheet = "" }) {
            Column(Modifier.padding(bottom = 24.dp)) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).clip(RoundedCornerShape(30.dp))
                        .background(MaterialTheme.colorScheme.surface).padding(horizontal = 14.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    REACTIONS.forEach { e ->
                        Text(
                            e, fontSize = 28.sp,
                            modifier = Modifier.clip(CircleShape)
                                .background(if (selMsg.myReact == e) Electric.copy(alpha = 0.25f) else Color.Transparent)
                                .clickable { ctl.react(selMsg.id, e); sheet = "" }.padding(4.dp),
                        )
                    }
                }
                ActionRow(Icons.Default.Info, "Info") { infoId = selMsg.id; sheet = "" }
                val txt = selMsg.text
                if (txt != null && Media.stickerOf(txt) == null && Media.contactOf(txt) == null) {
                    ActionRow(Icons.Default.ContentCopy, "Copy") {
                        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("message", txt))
                        sheet = ""
                    }
                }
                if (selMsg.mine && selMsg.status == Status.FAILED) ActionRow(Icons.Default.Info, "Retry") { ctl.retry(selMsg.id); sheet = "" }
                ActionRow(Icons.Default.Delete, "Delete", Offline) { delId = selMsg.id; sheet = "" }
            }
        }
    }

    // ---- dialogs
    val delMsg = s.messages.firstOrNull { it.id == delId }
    if (delMsg != null) {
        AlertDialog(
            onDismissRequest = { delId = null },
            title = { Text("Delete message?") },
            text = { Text("Ye sirf is phone se hatega. Doosre phone par kuch nahi badlega.") },
            confirmButton = { TextButton(onClick = { ctl.deleteMessage(delMsg.id); delId = null }) { Text("Delete", color = Offline) } },
            dismissButton = { TextButton(onClick = { delId = null }) { Text("Cancel") } },
        )
    }
    if (delChat) {
        AlertDialog(
            onDismissRequest = { delChat = false },
            title = { Text("Delete chat?") },
            text = { Text("$title ke saare messages, previews aur is chat ki received files is phone se hat jayengi.") },
            confirmButton = { TextButton(onClick = { delChat = false; ctl.deleteChat(s.openAddr); onBack() }) { Text("Delete", color = Offline) } },
            dismissButton = { TextButton(onClick = { delChat = false }) { Text("Cancel") } },
        )
    }
    val infoMsg = s.messages.firstOrNull { it.id == infoId }
    if (infoMsg != null) InfoDialog(infoMsg, title, fs) { infoId = null }
    val viewMsg = s.messages.firstOrNull { it.id == viewId }
    if (viewMsg != null) {
        MediaViewer(
            viewMsg, onClose = { viewId = null },
            onReact = { e -> ctl.react(viewMsg.id, e) },
            onMenu = { selId = viewMsg.id; viewId = null; sheet = "msg" },
        )
    }
}

@Composable
private fun androidx.compose.foundation.layout.RowScope.AttachTile(icon: ImageVector, label: String, color: Color, onClick: () -> Unit) {
    Column(
        Modifier.weight(1f).clickable(onClick = onClick).padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(58.dp).clip(RoundedCornerShape(20.dp)).background(color), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text(label, fontSize = 13.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun EmojiGrid(list: List<String>, onPick: (String) -> Unit) {
    LazyVerticalGrid(columns = GridCells.Fixed(8), modifier = Modifier.heightIn(max = 340.dp)) {
        items(list) { e ->
            Text(e, fontSize = 27.sp, textAlign = TextAlign.Center, modifier = Modifier.clickable { onPick(e) }.padding(vertical = 6.dp))
        }
    }
}

@Composable
private fun StickerGrid(list: List<String>, onPick: (String) -> Unit) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(4), modifier = Modifier.heightIn(max = 340.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        items(list) { e ->
            Box(
                Modifier.clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surface).clickable { onPick(e) }.padding(vertical = 10.dp),
                contentAlignment = Alignment.Center,
            ) { Text(e, fontSize = 44.sp) }
        }
    }
}

// ---------------------------------------------------------------- message info

@Composable
private fun InfoDialog(m: Msg, who: String, fs: Int, onClose: () -> Unit) {
    val gray = tickGray()
    val blue = seenBlue()
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                    Text("Message info", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = if (m.mine) Alignment.CenterEnd else Alignment.CenterStart) {
                    Box(
                        Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(18.dp))
                            .background(if (m.mine) outBubble() else MaterialTheme.colorScheme.surface).padding(12.dp),
                    ) {
                        Text(Media.previewOf(m), fontSize = fs.sp, maxLines = 4, overflow = TextOverflow.Ellipsis)
                    }
                }
                if (m.mine) {
                    InfoRow("\u2713\u2713", blue, "Seen", if (m.seenAt > 0) timeFmt.format(Date(m.seenAt)) else "\u2014", dim)
                    InfoRow("\u2713\u2713", gray, "Delivered", if (m.deliveredAt > 0) timeFmt.format(Date(m.deliveredAt)) else "\u2014", dim)
                    InfoRow("\u2713", gray, "Sent", timeFmt.format(Date(m.time)), dim)
                } else {
                    InfoRow("\u2713\u2713", gray, "Received from $who", timeFmt.format(Date(m.time)), dim)
                }
            }
        }
    }
}

@Composable
private fun InfoRow(tick: String, tickColor: Color, title: String, time: String, dim: Color) {
    Column {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(tick, color = tickColor, fontWeight = FontWeight.Bold, modifier = Modifier.width(36.dp))
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, modifier = Modifier.weight(1f))
            Text(time, color = dim)
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
    }
}

// ---------------------------------------------------------------- photo viewer with reactions

@Composable
private fun MediaViewer(m: Msg, onClose: () -> Unit, onReact: (String) -> Unit, onMenu: () -> Unit) {
    val path = if (!m.mine && m.savedPath != null && Media.isImage(m.fileName ?: "")) m.savedPath else m.thumb
    val bmp = rememberBitmap(path, 1600)
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
            if (bmp != null) Image(bmp, m.fileName, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            Row(Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Close", tint = Color.White) }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onMenu) { Icon(Icons.Default.MoreVert, "More", tint = Color.White) }
            }
            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0x99000000)).padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("${m.fileName ?: ""} \u2022 ${formatSize(m.fileSize)}", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier.clip(RoundedCornerShape(30.dp)).background(Color(0x33FFFFFF)).padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    REACTIONS.forEach { e ->
                        Text(
                            e, fontSize = 28.sp,
                            modifier = Modifier.clip(CircleShape)
                                .background(if (m.myReact == e) Color(0x66FFFFFF) else Color.Transparent)
                                .clickable { onReact(e) }.padding(4.dp),
                        )
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- bubbles

@Composable
private fun Bubble(m: Msg, fs: Int, ctl: BtController, isLastMine: Boolean, onMenu: () -> Unit, onOpenMedia: () -> Unit) {
    val vis = remember { MutableTransitionState(false).apply { targetState = true } }
    val sticker = Media.stickerOf(m.text)
    val contact = Media.contactOf(m.text)
    val name = m.fileName
    val fg = MaterialTheme.colorScheme.onSurface
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    AnimatedVisibility(visibleState = vis, enter = fadeIn(tween(200)) + slideInVertically(tween(220)) { it / 3 }) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = if (m.mine) Alignment.End else Alignment.Start) {
            val shape = RoundedCornerShape(
                topStart = 20.dp, topEnd = 20.dp,
                bottomStart = if (m.mine) 20.dp else 6.dp, bottomEnd = if (m.mine) 6.dp else 20.dp,
            )
            val bg = if (sticker != null) Modifier
            else Modifier.background(if (m.mine) outBubble() else MaterialTheme.colorScheme.surface, shape)
            Column(
                Modifier.widthIn(max = 300.dp).then(bg)
                    .pointerInput(m.id) { detectTapGestures(onLongPress = { onMenu() }, onTap = { if (sticker == null && contact == null && m.text != null) onMenu() }) }
                    .padding(if (sticker != null) 2.dp else 10.dp),
            ) {
                when {
                    sticker != null -> Text(sticker, fontSize = 72.sp)
                    contact != null -> ContactBody(contact.first, contact.second, fg, dim)
                    m.text != null -> Text(m.text, fontSize = fs.sp, color = fg, modifier = Modifier.padding(horizontal = 2.dp))
                    name != null && Media.isVoice(name) -> VoiceBody(m, dim)
                    else -> FileBody(m, ctl, fg, onMenu, onOpenMedia)
                }
                Row(Modifier.align(Alignment.End).padding(top = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(timeFmt.format(Date(m.time)), fontSize = 11.sp, color = dim)
                    if (m.mine) Ticks(m)
                }
                val reacts = listOfNotNull(m.myReact, m.theirReact).distinct()
                if (reacts.isNotEmpty()) {
                    Box(
                        Modifier.padding(top = 4.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.background)
                            .padding(horizontal = 7.dp, vertical = 1.dp),
                    ) { Text(reacts.joinToString(""), fontSize = 14.sp) }
                }
                if (m.mine && m.status == Status.FAILED && m.text != null) {
                    TextButton(onClick = { ctl.retry(m.id) }) { Text("Retry") }
                }
            }
            if (isLastMine && m.mine) {
                val label = when {
                    m.status == Status.FAILED -> "Not sent"
                    m.seenAt > 0 -> "Seen"
                    m.deliveredAt > 0 -> "Delivered"
                    m.status == Status.SENDING -> "Sending\u2026"
                    m.status == Status.SENT || m.status == Status.DELIVERED || m.status == Status.DONE -> "Sent"
                    else -> ""
                }
                if (label.isNotEmpty()) Text(label, fontSize = 11.sp, color = dim, modifier = Modifier.padding(top = 2.dp, end = 4.dp))
            }
        }
    }
}

@Composable
private fun ContactBody(name: String, number: String, fg: Color, dim: Color) {
    Row(Modifier.width(220.dp), verticalAlignment = Alignment.CenterVertically) {
        Avatar(name, 42)
        Spacer(Modifier.size(10.dp))
        Column {
            Text(name, fontWeight = FontWeight.SemiBold, color = fg, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(number, fontSize = 13.sp, color = dim)
        }
    }
}

@Composable
private fun VoiceBody(m: Msg, dim: Color) {
    val playingId by VoicePlayer.playing.collectAsState()
    val prog by VoicePlayer.progress.collectAsState()
    val isPlaying = playingId == m.id
    val secs = Media.voiceSecs(m.fileName ?: "")
    LaunchedEffect(isPlaying) { while (isPlaying) { VoicePlayer.tick(); delay(150) } }
    val path = m.savedPath
    val ready = path != null && (m.mine || m.status == Status.DONE)
    Row(Modifier.width(220.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(Electric).clickable(enabled = ready) { if (path != null) VoicePlayer.toggle(m.id, path) },
            contentAlignment = Alignment.Center,
        ) { Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Play", tint = Color.White) }
        Spacer(Modifier.size(10.dp))
        Column(Modifier.weight(1f)) {
            LinearProgressIndicator(progress = { if (isPlaying) prog else 0f }, modifier = Modifier.fillMaxWidth(), color = Electric)
            Spacer(Modifier.height(4.dp))
            Text(
                if (m.status == Status.TRANSFERRING || m.status == Status.OFFERED) "${Media.fmtSecs(secs)} \u2022 ${(m.progress * 100).toInt()}%" else Media.fmtSecs(secs),
                fontSize = 12.sp, color = dim,
            )
        }
    }
}

@Composable
private fun FileBody(m: Msg, ctl: BtController, fg: Color, onLong: () -> Unit, onOpen: () -> Unit) {
    val name = m.fileName ?: "file"
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    val bmp = rememberBitmap(m.thumb, 640)
    if (bmp != null) {
        Box(
            Modifier.fillMaxWidth().heightIn(max = 280.dp).clip(RoundedCornerShape(14.dp))
                .pointerInput(m.id) { detectTapGestures(onTap = { onOpen() }, onLongPress = { onLong() }) },
            contentAlignment = Alignment.Center,
        ) {
            Image(bmp, name, Modifier.fillMaxWidth(), contentScale = ContentScale.Fit)
            if (Media.isVideo(name)) {
                Box(Modifier.size(52.dp).clip(CircleShape).background(Color(0x99000000)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.PlayArrow, "Video", tint = Color.White, modifier = Modifier.size(34.dp))
                }
            }
        }
        Text("$name \u2022 ${formatSize(m.fileSize)}", color = dim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
    } else {
        Row(Modifier.width(220.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Description, null, tint = Electric, modifier = Modifier.size(34.dp))
            Spacer(Modifier.size(10.dp))
            Column {
                Text(name, color = fg, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(formatSize(m.fileSize), color = dim, fontSize = 12.sp)
            }
        }
    }
    val statusText = when (m.status) {
        Status.OFFERED -> if (m.mine) "Waiting for them to accept\u2026" else "Incoming file"
        Status.TRANSFERRING -> "${(m.progress * 100).toInt()}%"
        Status.DONE -> if (m.mine) "Sent" else "Saved"
        Status.REJECTED -> "Rejected"
        Status.CANCELLED -> "Cancelled"
        Status.FAILED -> "Transfer failed"
        else -> ""
    }
    if (m.status == Status.TRANSFERRING) {
        LinearProgressIndicator(progress = { m.progress }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), color = Electric)
    }
    if (statusText.isNotEmpty()) Text(statusText, color = dim, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
    Row {
        if (!m.mine && m.status == Status.OFFERED) {
            TextButton(onClick = { ctl.respondToOffer(m.id, false) }) { Text("Reject") }
            TextButton(onClick = { ctl.respondToOffer(m.id, true) }) { Text("Accept", fontWeight = FontWeight.Bold) }
        }
        if (m.status == Status.TRANSFERRING || (m.mine && m.status == Status.OFFERED)) {
            TextButton(onClick = { ctl.cancelTransfer(m.id) }) { Text("Cancel") }
        }
        if (m.mine && m.status == Status.FAILED) {
            TextButton(onClick = { ctl.retry(m.id) }) { Text("Retry", fontWeight = FontWeight.Bold) }
        }
    }
}
