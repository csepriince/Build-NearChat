@file:OptIn(ExperimentalMaterial3Api::class)

package com.nearchat.app.ui

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.nearchat.app.core.BtController
import com.nearchat.app.core.ChatMeta
import com.nearchat.app.core.LinkState
import com.nearchat.app.core.UiState

private enum class Screen { CHATS, NEARBY, SETTINGS, CHAT, PROFILE, WALL, CONTACT }

@Composable
fun NearChatApp(ctl: BtController) {
    val s by ctl.state.collectAsState()
    val mode by ctl.themeMode.collectAsState()
    val dark = when (mode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    NearChatTheme(dark) { Root(ctl, s) }
}

@Composable
private fun Root(ctl: BtController, s: UiState) {
    val ctx = LocalContext.current
    var screen by rememberSaveable { mutableStateOf(Screen.CHATS) }
    var wallFrom by rememberSaveable { mutableStateOf(Screen.SETTINGS) }
    var profFrom by rememberSaveable { mutableStateOf(Screen.SETTINGS) }
    val snack = remember { SnackbarHostState() }
    val profile by ctl.profile.collectAsState()
    var rationale by remember { mutableStateOf(false) }
    var after by remember { mutableStateOf<(() -> Unit)?>(null) }
    var deleteTarget by remember { mutableStateOf<ChatMeta?>(null) }
    var renameTarget by remember { mutableStateOf<ChatMeta?>(null) }
    var renameText by remember { mutableStateOf("") }

    val needed: Array<String> = remember {
        if (Build.VERSION.SDK_INT >= 31) arrayOf(
            Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE,
        ) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }
    fun granted() = needed.all { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED }

    val enableBt = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val a = after; after = null
        if (r.resultCode == Activity.RESULT_OK) { ctl.startListening(); a?.invoke() }
        else ctl.report("Bluetooth ON kiye bina NearChat kaam nahi karega.")
    }
    fun withBluetooth(action: () -> Unit) {
        if (ctl.bluetoothOn()) { ctl.startListening(); action() }
        else { after = action; enableBt.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)) }
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        val a = after; after = null
        if (res.values.all { it }) { if (a != null) withBluetooth(a) else if (ctl.bluetoothOn()) ctl.startListening() }
        else ctl.report("Permission ke bina nearby devices nahi mil sakte. Settings > Help & permissions se allow karein.")
    }
    fun ensure(action: () -> Unit) {
        if (granted()) withBluetooth(action) else { after = action; rationale = true }
    }
    val visibleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { }
    fun makeVisible() = ensure {
        visibleLauncher.launch(
            Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE).putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300),
        )
    }
    fun openNearby() = ensure { screen = Screen.NEARBY; ctl.startScan() }

    LaunchedEffect(Unit) { if (granted() && ctl.bluetoothOn()) ctl.startListening() }
    LaunchedEffect(s.link) { if (s.link == LinkState.CONNECTED) screen = Screen.CHAT }
    LaunchedEffect(s.error) { s.error?.let { snack.showSnackbar(it); ctl.clearError() } }
    BackHandler(screen != Screen.CHATS) {
        when (screen) {
            Screen.CHAT -> screen = Screen.CHATS
            Screen.CONTACT -> screen = Screen.CHAT
            Screen.PROFILE -> screen = profFrom
            Screen.WALL -> screen = wallFrom
            Screen.NEARBY -> { ctl.stopScan(); screen = Screen.CHATS }
            else -> screen = Screen.CHATS
        }
    }

    val showNav = screen == Screen.CHATS || screen == Screen.NEARBY || screen == Screen.SETTINGS
    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (showNav) {
                NavigationBar(containerColor = MaterialTheme.colorScheme.background) {
                    NavigationBarItem(
                        selected = screen == Screen.CHATS, onClick = { screen = Screen.CHATS },
                        icon = { Icon(Icons.Default.Chat, "Chats") }, label = { Text("Chats") },
                    )
                    NavigationBarItem(
                        selected = screen == Screen.NEARBY, onClick = { openNearby() },
                        icon = { Icon(Icons.Default.Bluetooth, "Nearby") }, label = { Text("Nearby") },
                    )
                    NavigationBarItem(
                        selected = screen == Screen.SETTINGS, onClick = { screen = Screen.SETTINGS },
                        icon = { Icon(Icons.Default.Settings, "Settings") }, label = { Text("Settings") },
                    )
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            AnimatedContent(
                targetState = screen,
                transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(150)) },
                label = "nav",
            ) { sc ->
                when (sc) {
                    Screen.CHATS -> HomeScreen(
                        s, profile,
                        onFind = { openNearby() },
                        onProfile = { profFrom = Screen.CHATS; screen = Screen.PROFILE },
                        onOpenConnected = { screen = Screen.CHAT },
                        onOpen = { m -> if (ctl.openChat(m)) screen = Screen.CHAT },
                        onDelete = { deleteTarget = it },
                        onRename = { renameText = it.name; renameTarget = it },
                    )
                    Screen.NEARBY -> NearbyScreen(
                        s,
                        onRescan = { ensure { ctl.startScan() } },
                        onVisible = { makeVisible() },
                        onConnect = { d -> ensure { ctl.connect(d) } },
                        onCancel = { ctl.disconnect() },
                    )
                    Screen.CHAT -> ChatScreen(
                        s, ctl,
                        onBack = { screen = Screen.CHATS },
                        onContactInfo = { screen = Screen.CONTACT },
                        onWallpaper = { wallFrom = Screen.CHAT; screen = Screen.WALL },
                        onReconnect = { ensure { ctl.reconnect() } },
                    )
                    Screen.CONTACT -> ContactInfoScreen(
                        s, ctl,
                        onBack = { screen = Screen.CHAT },
                        onWall = { wallFrom = Screen.CONTACT; screen = Screen.WALL },
                        onDeleted = { screen = Screen.CHATS },
                    )
                    Screen.SETTINGS -> SettingsScreen(
                        ctl, profile,
                        onProfile = { profFrom = Screen.SETTINGS; screen = Screen.PROFILE },
                        onWall = { wallFrom = Screen.SETTINGS; screen = Screen.WALL },
                    )
                    Screen.PROFILE -> ProfileScreen(ctl, profile, onBack = { screen = profFrom })
                    Screen.WALL -> WallpaperScreen(ctl, onBack = { screen = wallFrom })
                }
            }
        }
    }

    deleteTarget?.let { t ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete chat?") },
            text = { Text("${t.name} ke saare messages, previews aur is chat ki received files is phone se hat jayengi.") },
            confirmButton = { TextButton(onClick = { ctl.deleteChat(t.address); deleteTarget = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Cancel") } },
        )
    }

    renameTarget?.let { t ->
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("Rename contact") },
            text = { OutlinedTextField(value = renameText, onValueChange = { renameText = it.take(25) }, singleLine = true) },
            confirmButton = { TextButton(onClick = { ctl.renamePeer(t.address, renameText); renameTarget = null }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("Cancel") } },
        )
    }

    s.incoming?.let { inc ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Connection request") },
            text = {
                Text(
                    "${inc.deviceName} aapse connect hona chahta hai.\n\n" +
                        "Security code: ${inc.code}\n" +
                        "Dono phones par yahi code dikhna chahiye. Alag ho to Reject karein.",
                )
            },
            confirmButton = { TextButton(onClick = { ctl.respondToRequest(true) }) { Text("Accept") } },
            dismissButton = { TextButton(onClick = { ctl.respondToRequest(false) }) { Text("Reject") } },
        )
    }

    if (rationale) {
        AlertDialog(
            onDismissRequest = { rationale = false; after = null },
            title = { Text("Permission chahiye") },
            text = {
                Text(
                    if (Build.VERSION.SDK_INT >= 31)
                        "NearChat ko 'Nearby devices' permission chahiye taaki wo paas ke phones dhoondh sake, unse connect ho sake, " +
                            "aur aapka phone dusron ko dikha sake. Aapki location use nahi hoti aur internet ki zaroorat nahi."
                    else
                        "Android 11 ya kam par Bluetooth scan ke liye Location permission zaroori hoti hai. " +
                            "NearChat aapki location store ya share nahi karta; ye sirf nearby phones dhoondhne ke liye hai.",
                )
            },
            confirmButton = { TextButton(onClick = { rationale = false; permLauncher.launch(needed) }) { Text("Allow") } },
            dismissButton = { TextButton(onClick = { rationale = false; after = null }) { Text("Not now") } },
        )
    }
}
