package com.nearchat.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val Navy = Color(0xFF0B1F4B)
val Electric = Color(0xFF4F6BFF)
val Violet = Color(0xFF7C4DFF)
val Online = Color(0xFF22C55E)
val Offline = Color(0xFFEF4444)

val brand = Brush.horizontalGradient(listOf(Electric, Violet))

val LocalDark = staticCompositionLocalOf { false }

@Composable
fun outBubble(): Color = if (LocalDark.current) Color(0xFF2B3B80) else Color(0xFFDCE5FF)

@Composable
fun tickGray(): Color = if (LocalDark.current) Color(0xFF8791A8) else Color(0xFF9AA3B8)

@Composable
fun seenBlue(): Color = if (LocalDark.current) Color(0xFF5CC0FF) else Color(0xFF1E7BFF)

/** Chat wallpapers. Index 6 (= size of this list) means "photo from gallery". */
val Wallpapers: List<Pair<String, List<Color>>> = listOf(
    "Default" to listOf(Color(0xFFEEF2FF), Color(0xFFFFFFFF)),
    "Ocean" to listOf(Color(0xFFD6ECFF), Color(0xFFC3D4FF)),
    "Sunset" to listOf(Color(0xFFFFE5D3), Color(0xFFFFD0E6)),
    "Mint" to listOf(Color(0xFFD9F6E8), Color(0xFFCFEAFF)),
    "Night" to listOf(Color(0xFF0B1F4B), Color(0xFF1B1D21)),
    "Gold" to listOf(Color(0xFFFFF1C2), Color(0xFFFFD9A0)),
)

fun wallBrush(i: Int): Brush = Brush.verticalGradient(Wallpapers[i.coerceIn(0, Wallpapers.lastIndex)].second)

private val LightScheme = lightColorScheme(
    primary = Navy, onPrimary = Color.White, secondary = Electric,
    background = Color.White, onBackground = Color(0xFF0E1630),
    surface = Color(0xFFF1F3FA), onSurface = Color(0xFF0E1630),
    surfaceVariant = Color(0xFFE4E8F6), onSurfaceVariant = Color(0xFF55607F),
    error = Offline,
)

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF8FA2FF), onPrimary = Navy, secondary = Electric,
    background = Color(0xFF15171B), onBackground = Color(0xFFEDEFF7),
    surface = Color(0xFF252A32), onSurface = Color(0xFFEDEFF7),
    surfaceVariant = Color(0xFF343944), onSurfaceVariant = Color(0xFFA9B1C6),
    error = Offline,
)

@Composable
fun NearChatTheme(dark: Boolean, content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalDark provides dark) {
        MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme, content = content)
    }
}
