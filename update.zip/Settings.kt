@file:OptIn(ExperimentalMaterial3Api::class)

package com.nearchat.app.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.nearchat.app.core.BtController
import com.nearchat.app.core.Profile
import com.nearchat.app.core.UiState
import java.io.File

@Composable
private fun SectionTitle(t: String) {
    Text(
        t.uppercase(), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(start = 18.dp, top = 18.dp, bottom = 4.dp),
    )
}

@Composable
private fun SettingRow(title: String, subtitle: String? = null, onClick: (() -> Unit)? = null, trailing: @Composable () -> Unit = {}) {
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    Row(
        Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            if (subtitle != null) Text(subtitle, fontSize = 12.sp, color = dim)
        }
        trailing()
    }
}

@Composable
fun SettingsScreen(ctl: BtController, profile: Profile, onProfile: () -> Unit, onWall: () -> Unit) {
    val ctx = LocalContext.current
    val mode by ctl.themeMode.collectAsState()
    val rr by ctl.readReceipts.collectAsState()
    val hist by ctl.saveHistory.collectAsState()
    var confirmAll by remember { mutableStateOf(false) }
    val shownName = profile.name.ifBlank { ctl.phoneName() }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("Settings", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 18.dp, top = 14.dp, bottom = 6.dp))
        Row(Modifier.fillMaxWidth().clickable(onClick = onProfile).padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Avatar(shownName, 60, photo = profile.photo)
            Spacer(Modifier.size(14.dp))
            Column(Modifier.weight(1f)) {
                Text(shownName, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                if (profile.bio.isNotBlank()) Text(profile.bio, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        SectionTitle("Appearance")
        Row(Modifier.padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("System", "Light", "Dark").forEachIndexed { i, l ->
                FilterChip(selected = mode == i, onClick = { ctl.setTheme(i) }, label = { Text(l) })
            }
        }
        SettingRow("Chat wallpaper & text size", onClick = onWall)
        SectionTitle("Chats")
        SettingRow("Save chat history", "Stored only on this phone", trailing = { Switch(checked = hist, onCheckedChange = { ctl.setSaveHistory(it) }) })
        SettingRow("Received files", ctl.receivedDir().absolutePath)
        SectionTitle("Privacy")
        SettingRow("Read receipts", "Blue ticks", trailing = { Switch(checked = rr, onCheckedChange = { ctl.setReadReceipts(it) }) })
        SettingRow("Encryption", "AES-256-GCM \u2022 verify with the security code")
        SectionTitle("Help")
        SettingRow("Help & permissions", onClick = {
            ctx.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        })
        SettingRow("About NearChat", "Version 1.1 \u2022 Chat Closer")
        SettingRow("Delete all chats", onClick = { confirmAll = true })
        Spacer(Modifier.height(24.dp))
    }
    if (confirmAll) {
        AlertDialog(
            onDismissRequest = { confirmAll = false },
            title = { Text("Delete all chats?") },
            text = { Text("Saari chats aur unki received files is phone se hat jayengi.") },
            confirmButton = { TextButton(onClick = { confirmAll = false; ctl.deleteAllChats() }) { Text("Delete", color = Offline) } },
            dismissButton = { TextButton(onClick = { confirmAll = false }) { Text("Cancel") } },
        )
    }
}

// ============================================================ PROFILE

@Composable
fun ProfileScreen(ctl: BtController, profile: Profile, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(profile.name) }
    var bio by remember { mutableStateOf(profile.bio) }
    var sheet by remember { mutableStateOf(false) }
    var camUri by remember { mutableStateOf<Uri?>(null) }
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) ctl.setProfilePhoto(u) }
    val takePic = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = camUri
        if (ok && u != null) ctl.setProfilePhoto(u)
    }
    val shown = name.trim().ifBlank { ctl.phoneName() }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
            Text("Profile", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
            Box(Modifier.align(Alignment.CenterHorizontally).padding(vertical = 10.dp)) {
                Avatar(shown, 112, photo = profile.photo)
                Box(
                    Modifier.align(Alignment.BottomEnd).size(38.dp).clip(CircleShape).background(Electric).clickable { sheet = true },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Default.CameraAlt, "Change photo", tint = Color.White, modifier = Modifier.size(20.dp)) }
            }
            OutlinedTextField(value = name, onValueChange = { name = it.take(25) }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = bio, onValueChange = { bio = it.take(80) }, label = { Text("About") }, modifier = Modifier.fillMaxWidth())
            Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Available", "Busy", "At work").forEach { b -> FilterChip(selected = bio == b, onClick = { bio = b }, label = { Text(b) }) }
            }
            SettingRow("Phone name", ctl.phoneName())
            Text("Preview", fontSize = 12.sp, color = dim, modifier = Modifier.padding(top = 10.dp, bottom = 6.dp))
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surface).padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Avatar(shown, 48, photo = profile.photo)
                Spacer(Modifier.size(12.dp))
                Column {
                    Text(shown, fontWeight = FontWeight.Bold)
                    if (bio.isNotBlank()) Text(bio, fontSize = 13.sp, color = dim)
                }
            }
            Spacer(Modifier.height(16.dp))
            GradientButton("Save", { ctl.saveProfile(name, bio); ctl.report("Profile saved") }, Modifier.fillMaxWidth())
            Spacer(Modifier.height(24.dp))
        }
    }
    if (sheet) {
        ModalBottomSheet(onDismissRequest = { sheet = false }) {
            Column(Modifier.padding(bottom = 24.dp)) {
                ActionRow(Icons.Default.Image, "Choose from gallery") { sheet = false; gallery.launch("image/*") }
                ActionRow(Icons.Default.CameraAlt, "Take photo") {
                    sheet = false
                    try {
                        val dir = File(ctx.cacheDir, "camera").apply { mkdirs() }
                        val f = File(dir, "PROFILE_${System.currentTimeMillis()}.jpg")
                        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
                        camUri = uri
                        takePic.launch(uri)
                    } catch (e: Exception) {
                        ctl.report("Camera khul nahi paya.")
                    }
                }
                if (profile.photo != null) ActionRow(Icons.Default.Delete, "Remove photo", Offline) { sheet = false; ctl.setProfilePhoto(null) }
            }
        }
    }
}

// ============================================================ WALLPAPER & TEXT SIZE

@Composable
fun WallpaperScreen(ctl: BtController, onBack: () -> Unit) {
    val wall by ctl.wall.collectAsState()
    val wallPath by ctl.wallPath.collectAsState()
    val font by ctl.fontLevel.collectAsState()
    val fs = when (font) { 0 -> 14; 2 -> 19; else -> 16 }
    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) ctl.setCustomWall(u) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
            Text("Wallpaper & text size", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
            Box(Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(18.dp))) {
                WallpaperLayer(wall, wallPath, Modifier.fillMaxSize())
                Column(Modifier.fillMaxSize().padding(12.dp)) {
                    Box(Modifier.clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).padding(10.dp)) {
                        Text("Kya haal hai?", fontSize = fs.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.align(Alignment.End).clip(RoundedCornerShape(16.dp)).background(outBubble()).padding(10.dp)) {
                        Text("Mast, tum batao", fontSize = fs.sp)
                    }
                }
            }
            SectionTitle("Wallpaper")
            val tiles = Wallpapers.size + 1
            for (rowStart in 0 until tiles step 3) {
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    for (i in rowStart until minOf(rowStart + 3, tiles)) {
                        val sel = wall == i
                        Box(
                            Modifier.weight(1f).height(90.dp).clip(RoundedCornerShape(16.dp))
                                .background(if (i < Wallpapers.size) Color.Transparent else MaterialTheme.colorScheme.surface)
                                .clickable { if (i < Wallpapers.size) ctl.setWall(i) else gallery.launch("image/*") },
                            contentAlignment = Alignment.BottomCenter,
                        ) {
                            if (i < Wallpapers.size) Box(Modifier.fillMaxSize().background(wallBrush(i)))
                            else Icon(Icons.Default.Image, null, modifier = Modifier.align(Alignment.Center))
                            Text(if (i < Wallpapers.size) Wallpapers[i].first else "Gallery", fontSize = 12.sp, color = if (i == 4) Color.White else Color(0xFF334155), modifier = Modifier.padding(bottom = 6.dp))
                            if (sel) Box(Modifier.fillMaxSize().background(Color.Transparent).clip(RoundedCornerShape(16.dp)).clickable { }) {
                                Box(Modifier.align(Alignment.TopEnd).padding(6.dp).size(22.dp).clip(CircleShape).background(Electric), contentAlignment = Alignment.Center) {
                                    Text("\u2713", color = Color.White, fontSize = 13.sp)
                                }
                            }
                        }
                    }
                    for (k in 0 until (3 - minOf(3, tiles - rowStart))) Spacer(Modifier.weight(1f))
                }
            }
            SectionTitle("Text size")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Small", "Medium", "Large").forEachIndexed { i, l ->
                    FilterChip(selected = font == i, onClick = { ctl.setFont(i) }, label = { Text(l) })
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

// ============================================================ CONTACT INFO

@Composable
fun ContactInfoScreen(s: UiState, ctl: BtController, onBack: () -> Unit, onWall: () -> Unit, onDeleted: () -> Unit) {
    val info = s.openInfo
    var rename by remember { mutableStateOf(false) }
    var nick by remember { mutableStateOf(info.nick ?: info.name) }
    var del by remember { mutableStateOf(false) }
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
            Text("Contact info", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Box(Modifier.align(Alignment.CenterHorizontally).padding(vertical = 12.dp)) { Avatar(info.display, 112, photo = info.photo) }
            Text(info.display, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterHorizontally))
            if (info.bio.isNotBlank()) Text(info.bio, color = dim, modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 4.dp))
            Spacer(Modifier.height(12.dp))
            SettingRow("Phone name", info.name)
            ActionRow(Icons.Default.Edit, "Rename contact") { nick = info.nick ?: info.name; rename = true }
            ActionRow(Icons.Default.Palette, "Chat wallpaper", onClick = onWall)
            ActionRow(Icons.Default.Delete, "Delete chat", Offline) { del = true }
        }
    }
    if (rename) {
        AlertDialog(
            onDismissRequest = { rename = false },
            title = { Text("Rename contact") },
            text = { OutlinedTextField(value = nick, onValueChange = { nick = it.take(25) }, singleLine = true) },
            confirmButton = { TextButton(onClick = { rename = false; ctl.renamePeer(s.openAddr, nick) }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { rename = false }) { Text("Cancel") } },
        )
    }
    if (del) {
        AlertDialog(
            onDismissRequest = { del = false },
            title = { Text("Delete chat?") },
            text = { Text("Saare messages aur received files is phone se hat jayengi.") },
            confirmButton = { TextButton(onClick = { del = false; ctl.deleteChat(s.openAddr); onDeleted() }) { Text("Delete", color = Offline) } },
            dismissButton = { TextButton(onClick = { del = false }) { Text("Cancel") } },
        )
    }
}
